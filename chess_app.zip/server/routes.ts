import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertGameSchema, insertMoveSchema } from "@shared/schema";
import { z } from "zod";
import { Chess } from "chess.js";

// Game session mapping
const gameSessions = new Map<number, { 
  chess: Chess, 
  whiteSocket?: WebSocket, 
  blackSocket?: WebSocket,
  spectators: WebSocket[] 
}>();

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Create WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // WebSocket connection handler
  wss.on('connection', (ws) => {
    console.log('New WebSocket connection established');
    
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        console.log('Received message:', data);
        
        // Handle different message types
        if (data.type === 'join_game' && data.gameId) {
          const gameId = Number(data.gameId);
          const gameSession = gameSessions.get(gameId);
          
          if (gameSession) {
            // Assign player to white or black based on user role
            if (data.color === 'white' && !gameSession.whiteSocket) {
              gameSession.whiteSocket = ws;
              ws.send(JSON.stringify({ type: 'game_joined', color: 'white', gameId }));
            } else if (data.color === 'black' && !gameSession.blackSocket) {
              gameSession.blackSocket = ws;
              ws.send(JSON.stringify({ type: 'game_joined', color: 'black', gameId }));
            } else {
              // Add as spectator
              gameSession.spectators.push(ws);
              ws.send(JSON.stringify({ type: 'game_joined', color: 'spectator', gameId }));
            }
            
            // Send current game state
            ws.send(JSON.stringify({
              type: 'game_state',
              fen: gameSession.chess.fen(),
              turn: gameSession.chess.turn(),
              gameId
            }));
          } else {
            ws.send(JSON.stringify({ type: 'error', message: 'Game not found' }));
          }
        } else if (data.type === 'make_move' && data.gameId && data.move) {
          const gameId = Number(data.gameId);
          const gameSession = gameSessions.get(gameId);
          
          if (gameSession) {
            try {
              // Validate that it's the player's turn
              const isWhite = gameSession.whiteSocket === ws;
              const isBlack = gameSession.blackSocket === ws;
              const turn = gameSession.chess.turn();
              
              if ((isWhite && turn === 'w') || (isBlack && turn === 'b')) {
                // Make the move
                gameSession.chess.move(data.move);
                
                // Broadcast new state to all connected clients
                const newState = {
                  type: 'game_state',
                  fen: gameSession.chess.fen(),
                  turn: gameSession.chess.turn(),
                  lastMove: data.move,
                  gameId
                };
                
                // Check if game is over
                if (gameSession.chess.isGameOver()) {
                  newState.isGameOver = true;
                  if (gameSession.chess.isCheckmate()) {
                    newState.result = turn === 'w' ? 'black' : 'white';
                  } else if (gameSession.chess.isDraw()) {
                    newState.result = 'draw';
                  }
                }
                
                const stateMsg = JSON.stringify(newState);
                
                if (gameSession.whiteSocket) {
                  gameSession.whiteSocket.send(stateMsg);
                }
                if (gameSession.blackSocket) {
                  gameSession.blackSocket.send(stateMsg);
                }
                gameSession.spectators.forEach(spec => {
                  spec.send(stateMsg);
                });
              } else {
                ws.send(JSON.stringify({ type: 'error', message: 'Not your turn' }));
              }
            } catch (error) {
              ws.send(JSON.stringify({ type: 'error', message: 'Invalid move' }));
            }
          } else {
            ws.send(JSON.stringify({ type: 'error', message: 'Game not found' }));
          }
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });
    
    ws.on('close', () => {
      console.log('WebSocket connection closed');
      
      // Clean up any game sessions where this socket was a player
      gameSessions.forEach((session, gameId) => {
        if (session.whiteSocket === ws) {
          session.whiteSocket = undefined;
        }
        if (session.blackSocket === ws) {
          session.blackSocket = undefined;
        }
        
        // Remove from spectators if present
        const spectatorIndex = session.spectators.indexOf(ws);
        if (spectatorIndex !== -1) {
          session.spectators.splice(spectatorIndex, 1);
        }
      });
    });
    
    // Send initial connection confirmation
    ws.send(JSON.stringify({ type: 'connected' }));
  });
  
  // API Routes
  
  // User routes
  app.get('/api/users/me', async (req: Request, res: Response) => {
    // In a real app, this would use session or JWT tokens
    // For demo, we'll use a hardcoded user
    const user = await storage.getUser(1);
    if (user) {
      // Don't send password to client
      const { password, ...userData } = user;
      res.json(userData);
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  });
  
  // Games routes
  app.get('/api/games/active', async (req: Request, res: Response) => {
    // Get active games for the current user
    const userId = 1; // Hardcoded for demo
    const games = await storage.getActiveGamesByUserId(userId);
    
    // Get opponent data for each game
    const gamesWithOpponents = await Promise.all(games.map(async (game) => {
      const opponentId = game.whiteId === userId ? game.blackId : game.whiteId;
      const opponent = await storage.getUser(opponentId);
      
      return {
        ...game,
        opponent: opponent ? {
          id: opponent.id,
          username: opponent.username,
          rating: opponent.rating,
        } : null,
        color: game.whiteId === userId ? 'white' : 'black'
      };
    }));
    
    res.json(gamesWithOpponents);
  });
  
  app.get('/api/games/history', async (req: Request, res: Response) => {
    // Get completed games for the current user
    const userId = 1; // Hardcoded for demo
    const games = await storage.getCompletedGamesByUserId(userId);
    
    // Get opponent data for each game
    const gamesWithOpponents = await Promise.all(games.map(async (game) => {
      const opponentId = game.whiteId === userId ? game.blackId : game.whiteId;
      const opponent = await storage.getUser(opponentId);
      
      const userColor = game.whiteId === userId ? 'white' : 'black';
      const userWon = (game.result === 'white' && userColor === 'white') || 
                     (game.result === 'black' && userColor === 'black');
      const isDraw = game.result === 'draw';
      
      return {
        ...game,
        opponent: opponent ? {
          id: opponent.id,
          username: opponent.username,
          rating: opponent.rating,
        } : null,
        color: userColor,
        outcome: userWon ? 'win' : (isDraw ? 'draw' : 'loss'),
      };
    }));
    
    res.json(gamesWithOpponents);
  });
  
  app.post('/api/games', async (req: Request, res: Response) => {
    try {
      const gameData = insertGameSchema.parse(req.body);
      const game = await storage.createGame(gameData);
      
      // Initialize chess game
      const chess = new Chess();
      gameSessions.set(game.id, { chess, spectators: [] });
      
      res.status(201).json(game);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid game data', errors: error.errors });
      }
      res.status(500).json({ message: 'Could not create game' });
    }
  });
  
  app.get('/api/games/:id', async (req: Request, res: Response) => {
    const gameId = parseInt(req.params.id, 10);
    if (isNaN(gameId)) {
      return res.status(400).json({ message: 'Invalid game ID' });
    }
    
    const game = await storage.getGame(gameId);
    if (!game) {
      return res.status(404).json({ message: 'Game not found' });
    }
    
    // Get moves
    const moves = await storage.getMovesByGameId(gameId);
    
    // Get player info
    const white = await storage.getUser(game.whiteId);
    const black = await storage.getUser(game.blackId);
    
    res.json({
      ...game,
      moves,
      white: white ? {
        id: white.id,
        username: white.username,
        rating: white.rating,
      } : null,
      black: black ? {
        id: black.id,
        username: black.username,
        rating: black.rating,
      } : null,
    });
  });
  
  // Leaderboard routes
  app.get('/api/leaderboard', async (req: Request, res: Response) => {
    const limit = parseInt(req.query.limit as string || '10', 10);
    const players = await storage.getTopPlayers(limit);
    
    // Format the players for the leaderboard
    const leaderboard = players.map(player => {
      const { password, ...userData } = player;
      return userData;
    });
    
    res.json(leaderboard);
  });
  
  // Daily tasks routes
  app.get('/api/tasks', async (req: Request, res: Response) => {
    const userId = 1; // Hardcoded for demo
    const tasks = await storage.getDailyTasksByUserId(userId);
    res.json(tasks);
  });
  
  // WebSocket handling
  wss.on('connection', (ws) => {
    let userId: number | null = null;
    let gameId: string | number | null = null;
    
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        switch (data.type) {
          case 'auth':
            // Authenticate user (in a real app, verify token)
            userId = 1; // Hardcoded for demo
            ws.send(JSON.stringify({ type: 'auth', success: true }));
            break;
            
          case 'join_game':
            if (!userId) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                message: 'Not authenticated' 
              }));
              break;
            }
            
            gameId = data.gameId;
            const gameIdNum = typeof gameId === 'number' ? gameId : parseInt(gameId, 10);
            if (isNaN(gameIdNum)) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                message: 'Invalid game ID' 
              }));
              break;
            }
            
            const game = await storage.getGame(gameIdNum);
            
            if (!game) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                message: 'Game not found' 
              }));
              break;
            }
            
            let gameSession = gameSessions.get(gameIdNum);
            if (!gameSession) {
              // Initialize game session if not exists
              const chess = new Chess();
              gameSession = { chess, spectators: [] };
              gameSessions.set(gameIdNum, gameSession);
            }
            
            // Join as player or spectator
            if (game.whiteId === userId) {
              gameSession.whiteSocket = ws;
            } else if (game.blackId === userId) {
              gameSession.blackSocket = ws;
            } else {
              gameSession.spectators.push(ws);
            }
            
            // Send current game state
            const moves = await storage.getMovesByGameId(gameIdNum);
            
            ws.send(JSON.stringify({
              type: 'game_state',
              fen: gameSession.chess.fen(),
              moves: moves.map(m => m.move),
              turn: gameSession.chess.turn(),
              inCheck: gameSession.chess.inCheck(),
              isGameOver: gameSession.chess.isGameOver(),
              result: game.result
            }));
            break;
            
          case 'make_move':
            if (!userId || !gameId) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                message: 'Not authenticated or not in a game' 
              }));
              break;
            }
            
            const moveGameId = gameId;
            const game2 = await storage.getGame(moveGameId);
            const gameSession2 = gameSessions.get(moveGameId);
            
            if (!game2 || !gameSession2) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                message: 'Game not found' 
              }));
              break;
            }
            
            // Check if it's the player's turn
            const isWhite = gameSession2.chess.turn() === 'w';
            if ((isWhite && game2.whiteId !== userId) || 
                (!isWhite && game2.blackId !== userId)) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                message: 'Not your turn' 
              }));
              break;
            }
            
            try {
              // Make the move
              const moveResult = gameSession2.chess.move(data.move);
              
              if (!moveResult) {
                ws.send(JSON.stringify({ 
                  type: 'error', 
                  message: 'Invalid move' 
                }));
                break;
              }
              
              // Save the move
              const moveData = {
                gameId: moveGameId,
                move: data.move,
                fen: gameSession2.chess.fen()
              };
              
              await storage.createMove(moveData);
              
              // Check if game is over
              let result = null;
              if (gameSession2.chess.isGameOver()) {
                if (gameSession2.chess.isDraw()) {
                  result = 'draw';
                } else {
                  result = gameSession2.chess.turn() === 'w' ? 'black' : 'white';
                }
                
                // Update game result
                await storage.updateGameResult(
                  moveGameId, 
                  result, 
                  gameSession2.chess.pgn()
                );
                
                // Update ratings and points
                if (result === 'white') {
                  await storage.updateUserRating(game2.whiteId, 4);
                  await storage.updateUserRating(game2.blackId, -2);
                  await storage.updateUserPoints(game2.whiteId, 4);
                  await storage.updateUserPoints(game2.blackId, -2);
                } else if (result === 'black') {
                  await storage.updateUserRating(game2.blackId, 4);
                  await storage.updateUserRating(game2.whiteId, -2);
                  await storage.updateUserPoints(game2.blackId, 4);
                  await storage.updateUserPoints(game2.whiteId, -2);
                } else {
                  // Draw - both get points
                  await storage.updateUserRating(game2.whiteId, 2);
                  await storage.updateUserRating(game2.blackId, 2);
                  await storage.updateUserPoints(game2.whiteId, 2);
                  await storage.updateUserPoints(game2.blackId, 2);
                }
              }
              
              // Broadcast the move to all players and spectators
              const moveMessage = JSON.stringify({
                type: 'move_made',
                move: data.move,
                fen: gameSession2.chess.fen(),
                turn: gameSession2.chess.turn(),
                inCheck: gameSession2.chess.inCheck(),
                isGameOver: gameSession2.chess.isGameOver(),
                result
              });
              
              if (gameSession2.whiteSocket && 
                  gameSession2.whiteSocket.readyState === WebSocket.OPEN) {
                gameSession2.whiteSocket.send(moveMessage);
              }
              
              if (gameSession2.blackSocket && 
                  gameSession2.blackSocket.readyState === WebSocket.OPEN) {
                gameSession2.blackSocket.send(moveMessage);
              }
              
              gameSession2.spectators.forEach(spectator => {
                if (spectator.readyState === WebSocket.OPEN) {
                  spectator.send(moveMessage);
                }
              });
            } catch (error) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                message: 'Invalid move: ' + (error instanceof Error ? error.message : 'Unknown error') 
              }));
            }
            break;
            
          case 'resign':
            if (!userId || !gameId) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                message: 'Not authenticated or not in a game' 
              }));
              break;
            }
            
            const resignGameId = gameId;
            const resignGame = await storage.getGame(resignGameId);
            
            if (!resignGame) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                message: 'Game not found' 
              }));
              break;
            }
            
            // Set game result based on who resigned
            const result = resignGame.whiteId === userId ? 'black' : 'white';
            
            // Update game result
            await storage.updateGameResult(
              resignGameId, 
              result, 
              gameSessions.get(resignGameId)?.chess.pgn() || ''
            );
            
            // Update ratings and points
            if (result === 'white') {
              await storage.updateUserRating(resignGame.whiteId, 4);
              await storage.updateUserRating(resignGame.blackId, -2);
              await storage.updateUserPoints(resignGame.whiteId, 4);
              await storage.updateUserPoints(resignGame.blackId, -2);
            } else {
              await storage.updateUserRating(resignGame.blackId, 4);
              await storage.updateUserRating(resignGame.whiteId, -2);
              await storage.updateUserPoints(resignGame.blackId, 4);
              await storage.updateUserPoints(resignGame.whiteId, -2);
            }
            
            // Notify players
            const resignMessage = JSON.stringify({
              type: 'game_over',
              result,
              reason: 'resignation'
            });
            
            const resignSession = gameSessions.get(resignGameId);
            if (resignSession) {
              if (resignSession.whiteSocket && 
                  resignSession.whiteSocket.readyState === WebSocket.OPEN) {
                resignSession.whiteSocket.send(resignMessage);
              }
              
              if (resignSession.blackSocket && 
                  resignSession.blackSocket.readyState === WebSocket.OPEN) {
                resignSession.blackSocket.send(resignMessage);
              }
              
              resignSession.spectators.forEach(spectator => {
                if (spectator.readyState === WebSocket.OPEN) {
                  spectator.send(resignMessage);
                }
              });
            }
            break;
            
          case 'offer_draw':
            if (!userId || !gameId) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                message: 'Not authenticated or not in a game' 
              }));
              break;
            }
            
            const drawGameId = gameId;
            const drawGame = await storage.getGame(drawGameId);
            const drawSession = gameSessions.get(drawGameId);
            
            if (!drawGame || !drawSession) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                message: 'Game not found' 
              }));
              break;
            }
            
            // Send draw offer to opponent
            const isDrawOfferFromWhite = drawGame.whiteId === userId;
            const drawOfferMessage = JSON.stringify({
              type: 'draw_offer',
              from: isDrawOfferFromWhite ? 'white' : 'black'
            });
            
            if (isDrawOfferFromWhite && 
                drawSession.blackSocket && 
                drawSession.blackSocket.readyState === WebSocket.OPEN) {
              drawSession.blackSocket.send(drawOfferMessage);
            } else if (!isDrawOfferFromWhite && 
                       drawSession.whiteSocket && 
                       drawSession.whiteSocket.readyState === WebSocket.OPEN) {
              drawSession.whiteSocket.send(drawOfferMessage);
            }
            break;
            
          case 'accept_draw':
            if (!userId || !gameId) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                message: 'Not authenticated or not in a game' 
              }));
              break;
            }
            
            const acceptDrawGameId = gameId;
            const acceptDrawGame = await storage.getGame(acceptDrawGameId);
            
            if (!acceptDrawGame) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                message: 'Game not found' 
              }));
              break;
            }
            
            // Update game result to draw
            await storage.updateGameResult(
              acceptDrawGameId, 
              'draw', 
              gameSessions.get(acceptDrawGameId)?.chess.pgn() || ''
            );
            
            // Update ratings and points (both get 2 for a draw)
            await storage.updateUserRating(acceptDrawGame.whiteId, 2);
            await storage.updateUserRating(acceptDrawGame.blackId, 2);
            await storage.updateUserPoints(acceptDrawGame.whiteId, 2);
            await storage.updateUserPoints(acceptDrawGame.blackId, 2);
            
            // Notify players
            const drawAcceptedMessage = JSON.stringify({
              type: 'game_over',
              result: 'draw',
              reason: 'agreement'
            });
            
            const acceptDrawSession = gameSessions.get(acceptDrawGameId);
            if (acceptDrawSession) {
              if (acceptDrawSession.whiteSocket && 
                  acceptDrawSession.whiteSocket.readyState === WebSocket.OPEN) {
                acceptDrawSession.whiteSocket.send(drawAcceptedMessage);
              }
              
              if (acceptDrawSession.blackSocket && 
                  acceptDrawSession.blackSocket.readyState === WebSocket.OPEN) {
                acceptDrawSession.blackSocket.send(drawAcceptedMessage);
              }
              
              acceptDrawSession.spectators.forEach(spectator => {
                if (spectator.readyState === WebSocket.OPEN) {
                  spectator.send(drawAcceptedMessage);
                }
              });
            }
            break;
        }
      } catch (error) {
        ws.send(JSON.stringify({ 
          type: 'error', 
          message: 'Invalid message format' 
        }));
      }
    });
    
    // Handle disconnections
    ws.on('close', () => {
      if (gameId) {
        const session = gameSessions.get(gameId);
        if (session) {
          if (session.whiteSocket === ws) {
            session.whiteSocket = undefined;
          } else if (session.blackSocket === ws) {
            session.blackSocket = undefined;
          } else {
            const index = session.spectators.indexOf(ws);
            if (index !== -1) {
              session.spectators.splice(index, 1);
            }
          }
        }
      }
    });
  });

  return httpServer;
}
