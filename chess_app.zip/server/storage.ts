import { 
  users, type User, type InsertUser,
  games, type Game, type InsertGame,
  moves, type Move, type InsertMove,
  dailyTasks, type DailyTask, type InsertDailyTask
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByTelegramId(telegramId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserRating(userId: number, newRating: number): Promise<User | undefined>;
  updateUserPoints(userId: number, pointsDelta: number): Promise<User | undefined>;
  updateUserCoins(userId: number, coinsDelta: number): Promise<User | undefined>;
  updateUserExperience(userId: number, xpDelta: number): Promise<User | undefined>;
  
  // Game operations
  createGame(game: InsertGame): Promise<Game>;
  getGame(id: number): Promise<Game | undefined>;
  getActiveGamesByUserId(userId: number): Promise<Game[]>;
  getCompletedGamesByUserId(userId: number): Promise<Game[]>;
  updateGameResult(gameId: number, result: string, pgn: string): Promise<Game | undefined>;
  
  // Move operations
  createMove(move: InsertMove): Promise<Move>;
  getMovesByGameId(gameId: number): Promise<Move[]>;
  
  // Leaderboard operations
  getTopPlayers(limit: number): Promise<User[]>;
  
  // Daily tasks operations
  getDailyTasksByUserId(userId: number): Promise<DailyTask[]>;
  createDailyTask(task: InsertDailyTask): Promise<DailyTask>;
  updateDailyTaskProgress(taskId: number, progress: number): Promise<DailyTask | undefined>;
  completeDailyTask(taskId: number): Promise<DailyTask | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private games: Map<number, Game>;
  private moves: Map<number, Move>;
  private dailyTasks: Map<number, DailyTask>;
  private userId: number;
  private gameId: number;
  private moveId: number;
  private taskId: number;

  constructor() {
    this.users = new Map();
    this.games = new Map();
    this.moves = new Map();
    this.dailyTasks = new Map();
    this.userId = 1;
    this.gameId = 1;
    this.moveId = 1;
    this.taskId = 1;
    
    // Add some initial users for demonstration
    this.createUser({
      username: "AlexKnight",
      password: "password123", // In a real app, this would be hashed
      telegramId: "12345"
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async getUserByTelegramId(telegramId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.telegramId === telegramId
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { 
      ...insertUser, 
      id,
      rating: 1200,
      level: 1,
      experience: 0,
      points: 0,
      coins: 10,
      playingStyle: {
        aggressive: 50,
        openingKnowledge: 30,
        endgameSkills: 30,
        tacticalVision: 40
      },
      createdAt: new Date(),
      telegramId: insertUser.telegramId || null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserRating(userId: number, newRating: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (user) {
      const updatedUser = { ...user, rating: newRating };
      this.users.set(userId, updatedUser);
      return updatedUser;
    }
    return undefined;
  }

  async updateUserPoints(userId: number, pointsDelta: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (user) {
      const updatedUser = { ...user, points: user.points + pointsDelta };
      this.users.set(userId, updatedUser);
      return updatedUser;
    }
    return undefined;
  }

  async updateUserCoins(userId: number, coinsDelta: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (user) {
      const updatedUser = { ...user, coins: user.coins + coinsDelta };
      this.users.set(userId, updatedUser);
      return updatedUser;
    }
    return undefined;
  }

  async updateUserExperience(userId: number, xpDelta: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (user) {
      let { experience, level } = user;
      experience += xpDelta;
      
      // Simple level up logic - each level requires level * 100 XP
      const xpNeeded = level * 100;
      if (experience >= xpNeeded) {
        experience -= xpNeeded;
        level += 1;
      }
      
      const updatedUser = { ...user, experience, level };
      this.users.set(userId, updatedUser);
      return updatedUser;
    }
    return undefined;
  }

  // Game operations
  async createGame(insertGame: InsertGame): Promise<Game> {
    const id = this.gameId++;
    const game: Game = {
      ...insertGame,
      id,
      result: null,
      pgn: '',
      startTime: new Date(),
      endTime: null,
      isRated: insertGame.isRated ?? true,
      bettingAmount: insertGame.bettingAmount ?? null
    };
    this.games.set(id, game);
    return game;
  }

  async getGame(id: number): Promise<Game | undefined> {
    return this.games.get(id);
  }

  async getActiveGamesByUserId(userId: number): Promise<Game[]> {
    return Array.from(this.games.values()).filter(
      (game) => (game.whiteId === userId || game.blackId === userId) && !game.result
    );
  }

  async getCompletedGamesByUserId(userId: number): Promise<Game[]> {
    return Array.from(this.games.values())
      .filter((game) => (game.whiteId === userId || game.blackId === userId) && game.result)
      .sort((a, b) => (b.endTime?.getTime() || 0) - (a.endTime?.getTime() || 0));
  }

  async updateGameResult(gameId: number, result: string, pgn: string): Promise<Game | undefined> {
    const game = await this.getGame(gameId);
    if (game) {
      const updatedGame = { 
        ...game, 
        result, 
        pgn, 
        endTime: new Date() 
      };
      this.games.set(gameId, updatedGame);
      return updatedGame;
    }
    return undefined;
  }

  // Move operations
  async createMove(insertMove: InsertMove): Promise<Move> {
    const id = this.moveId++;
    const move: Move = {
      ...insertMove,
      id,
      timestamp: new Date()
    };
    this.moves.set(id, move);
    return move;
  }

  async getMovesByGameId(gameId: number): Promise<Move[]> {
    return Array.from(this.moves.values())
      .filter(move => move.gameId === gameId)
      .sort((a, b) => {
        const aTime = a.timestamp ? a.timestamp.getTime() : 0;
        const bTime = b.timestamp ? b.timestamp.getTime() : 0;
        return aTime - bTime;
      });
  }

  // Leaderboard operations
  async getTopPlayers(limit: number): Promise<User[]> {
    return Array.from(this.users.values())
      .sort((a, b) => b.rating - a.rating)
      .slice(0, limit);
  }

  // Daily tasks operations
  async getDailyTasksByUserId(userId: number): Promise<DailyTask[]> {
    return Array.from(this.dailyTasks.values()).filter(
      (task) => task.userId === userId
    );
  }

  async createDailyTask(insertTask: InsertDailyTask): Promise<DailyTask> {
    const id = this.taskId++;
    const task: DailyTask = {
      ...insertTask,
      id,
      progress: 0,
      completed: false,
      createdAt: new Date()
    };
    this.dailyTasks.set(id, task);
    return task;
  }

  async updateDailyTaskProgress(taskId: number, progress: number): Promise<DailyTask | undefined> {
    const task = this.dailyTasks.get(taskId);
    if (task) {
      const newProgress = task.progress + progress;
      const completed = newProgress >= task.target;
      const updatedTask = { 
        ...task, 
        progress: Math.min(newProgress, task.target),
        completed 
      };
      this.dailyTasks.set(taskId, updatedTask);
      return updatedTask;
    }
    return undefined;
  }

  async completeDailyTask(taskId: number): Promise<DailyTask | undefined> {
    const task = this.dailyTasks.get(taskId);
    if (task) {
      const updatedTask = { ...task, progress: task.target, completed: true };
      this.dailyTasks.set(taskId, updatedTask);
      return updatedTask;
    }
    return undefined;
  }
}

export const storage = new MemStorage();
