import React, { useState, useEffect } from 'react';
import { Chess, coordsToSquare, squareToCoords, getPieceAtSquare, ChessMove } from '@/lib/chess';
import ChessPiece from './ChessPiece';

interface ChessBoardProps {
  fen: string;
  flipped?: boolean;
  lastMove?: ChessMove | null;
  possibleMoves?: Record<string, string[]>;
  selectedSquare?: string | null;
  onSquareClick: (square: string) => void;
}

const ChessBoard: React.FC<ChessBoardProps> = ({
  fen,
  flipped = false,
  lastMove = null,
  possibleMoves = {},
  selectedSquare = null,
  onSquareClick
}) => {
  const [boardSize, setBoardSize] = useState(0);
  const boardRef = React.useRef<HTMLDivElement>(null);

  // Resize board based on container size
  useEffect(() => {
    const updateBoardSize = () => {
      if (boardRef.current) {
        const containerWidth = boardRef.current.offsetWidth;
        setBoardSize(containerWidth);
      }
    };

    updateBoardSize();
    window.addEventListener('resize', updateBoardSize);
    return () => window.removeEventListener('resize', updateBoardSize);
  }, []);

  // Generate the 8x8 chess board grid
  const renderBoard = () => {
    const squares = [];

    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        // Apply flipping if necessary
        const displayRow = flipped ? 7 - row : row;
        const displayCol = flipped ? 7 - col : col;

        const squareName = coordsToSquare(displayRow, displayCol);
        const isLightSquare = (displayRow + displayCol) % 2 === 1;

        // Check if this square is the selected square
        const isSelected = selectedSquare === squareName;

        // Check if this square is part of the last move
        const isLastMoveFrom = lastMove && lastMove.from === squareName;
        const isLastMoveTo = lastMove && lastMove.to === squareName;

        // Check if this is a possible move destination
        const isPossibleMove = selectedSquare && 
                              possibleMoves[selectedSquare] && 
                              possibleMoves[selectedSquare].includes(squareName);

        // Get piece at this square
        const piece = getPieceAtSquare(fen, squareName);

        squares.push(
          <div 
            key={`${displayRow}-${displayCol}`}
            className={`
              chess-board-cell
              ${isLightSquare ? 'bg-board-light' : 'bg-board-dark'}
              ${isSelected ? 'border-2 border-yellow-400' : ''}
              ${(isLastMoveFrom || isLastMoveTo) ? 'highlight' : ''}
              ${isPossibleMove ? 'possible-move' : ''}
              relative
            `}
            style={{
              width: `${boardSize / 8}px`,
              height: `${boardSize / 8}px`
            }}
            onClick={() => onSquareClick(squareName)}
          >
            {/* Piece */}
            {piece && (
              <ChessPiece
                type={piece.type}
                color={piece.color}
                size={boardSize / 8}
              />
            )}

            {/* Coordinates */}
            {displayRow === 7 && (
              <div className="absolute bottom-0 right-0 text-xs p-0.5 opacity-70">
                {String.fromCharCode(97 + displayCol)}
              </div>
            )}
            {displayCol === 0 && (
              <div className="absolute top-0 left-0 text-xs p-0.5 opacity-70">
                {8 - displayRow}
              </div>
            )}
          </div>
        );
      }
    }

    return squares;
  };

  return (
    <div 
      ref={boardRef}
      className="mx-auto rounded-lg overflow-hidden shadow-lg border border-gray-300"
      style={{ maxWidth: '100%', width: '100%' }}
    >
      <div className="flex flex-wrap" style={{ width: `${boardSize}px`, height: `${boardSize}px` }}>
        {renderBoard()}
      </div>
    </div>
  );
};

export default ChessBoard;