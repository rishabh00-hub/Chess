
import React from 'react';

interface ChessPieceProps {
  type: string;
  color: 'w' | 'b';
  size: number;
}

const ChessPiece: React.FC<ChessPieceProps> = ({ type, color, size }) => {
  // Map piece type and color to Unicode chess piece
  const getPieceUnicode = (type: string, color: 'w' | 'b'): string => {
    const pieces: Record<string, Record<string, string>> = {
      'p': { 'w': '♙', 'b': '♟' },  // pawn
      'n': { 'w': '♘', 'b': '♞' },  // knight
      'b': { 'w': '♗', 'b': '♝' },  // bishop
      'r': { 'w': '♖', 'b': '♜' },  // rook
      'q': { 'w': '♕', 'b': '♛' },  // queen
      'k': { 'w': '♔', 'b': '♚' }   // king
    };
    
    return pieces[type]?.[color] || '';
  };

  const pieceStyle = {
    width: `${size}px`,
    height: `${size}px`,
    fontSize: `${size * 0.8}px`,
    color: color === 'w' ? '#FFF' : '#000',
    textShadow: color === 'w' ? '0 0 2px #000' : '0 0 2px #FFF',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute' as 'absolute',
    top: 0,
    left: 0,
    zIndex: 10,
    userSelect: 'none' as 'none',
    transform: 'translateZ(0)',  // Hardware acceleration
  };

  return (
    <div style={pieceStyle} className="chess-piece">
      {getPieceUnicode(type, color)}
    </div>
  );
};

export default ChessPiece;
