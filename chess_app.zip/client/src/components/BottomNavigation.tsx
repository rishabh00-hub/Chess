import { useLocation, Link } from 'wouter';
import { 
  Home, 
  BarChart3, 
  Play, 
  TrendingUp, 
  BookOpen 
} from 'lucide-react';

const BottomNavigation = () => {
  const [location] = useLocation();
  
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center h-16 max-w-lg mx-auto">
      <Link href="/">
        <div className={`flex flex-col items-center justify-center w-full h-full ${location === '/' ? 'active' : ''}`}>
          <Home className={`h-6 w-6 ${location === '/' ? 'text-accent' : 'text-gray-500'}`} />
          <span className={`text-xs mt-1 ${location === '/' ? 'text-accent font-medium' : 'text-gray-500'}`}>Home</span>
        </div>
      </Link>
      
      <Link href="/leaderboard">
        <div className={`flex flex-col items-center justify-center w-full h-full ${location === '/leaderboard' ? 'active' : ''}`}>
          <BarChart3 className={`h-6 w-6 ${location === '/leaderboard' ? 'text-accent' : 'text-gray-500'}`} />
          <span className={`text-xs mt-1 ${location === '/leaderboard' ? 'text-accent font-medium' : 'text-gray-500'}`}>Leaderboard</span>
        </div>
      </Link>
      
      <Link href="/play">
        <div className={`flex flex-col items-center justify-center w-full h-full ${location === '/play' ? 'active' : ''}`}>
          <div className="bg-accent rounded-full w-12 h-12 flex items-center justify-center">
            <Play className="h-7 w-7 text-white" />
          </div>
          <span className={`text-xs mt-1 ${location === '/play' ? 'text-accent font-medium' : 'text-gray-500'}`}>Play</span>
        </div>
      </Link>
      
      <Link href="/stats">
        <div className={`flex flex-col items-center justify-center w-full h-full ${location === '/stats' ? 'active' : ''}`}>
          <TrendingUp className={`h-6 w-6 ${location === '/stats' ? 'text-accent' : 'text-gray-500'}`} />
          <span className={`text-xs mt-1 ${location === '/stats' ? 'text-accent font-medium' : 'text-gray-500'}`}>Stats</span>
        </div>
      </Link>
      
      <Link href="/tutorial">
        <div className={`flex flex-col items-center justify-center w-full h-full ${location === '/tutorial' ? 'active' : ''}`}>
          <BookOpen className={`h-6 w-6 ${location === '/tutorial' ? 'text-accent' : 'text-gray-500'}`} />
          <span className={`text-xs mt-1 ${location === '/tutorial' ? 'text-accent font-medium' : 'text-gray-500'}`}>Tutorial</span>
        </div>
      </Link>
    </nav>
  );
};

export default BottomNavigation;
