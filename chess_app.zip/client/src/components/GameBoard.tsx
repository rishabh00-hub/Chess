import React, { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { X, MoreVertical } from 'lucide-react';
import ChessBoard from './ChessBoard';
import { useChessGame } from '@/hooks/useChessGame';
import { useToast } from '@/hooks/use-toast';

interface GameBoardProps {
  gameId: number;
  onExit: () => void;
}

const GameBoard: React.FC<GameBoardProps> = ({ gameId, onExit }) => {
  const { toast } = useToast();
  const [timeLeft, setTimeLeft] = useState({ white: 300, black: 300 }); // 5 minutes default
  
  // Fetch game data
  const { data: gameData, isLoading } = useQuery({
    queryKey: ['/api/games', gameId],
    retry: false,
  });
  
  // Use the chess game hook for game state and WebSocket
  const { 
    gameState, 
    isPendingMove,
    makeMove, 
    offerDraw, 
    resignGame,
    lastMove,
    selectSquare
  } = useChessGame(gameId);
  
  // Countdown timer effect
  useEffect(() => {
    if (!gameState || gameState.isGameOver) return;
    
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        const colorToUpdate = gameState.turn === 'w' ? 'white' : 'black';
        const newTime = { ...prev };
        newTime[colorToUpdate] = Math.max(0, newTime[colorToUpdate] - 1);
        
        // Check for time out
        if (newTime[colorToUpdate] === 0) {
          toast({
            title: "Time's up!",
            description: `${colorToUpdate === 'white' ? 'White' : 'Black'} lost on time`,
            variant: "destructive"
          });
          
          // In a real app, this would trigger resignation via WebSocket
          clearInterval(timer);
        }
        
        return newTime;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, [gameState, toast]);
  
  const handleSquareClick = (square: string) => {
    if (!gameState || isPendingMove || gameState.isGameOver) return;
    
    // Get piece at clicked square
    const piece = gameState.selectedSquare 
      ? null // Already have a selection, clicking is to move
      : gameState.fen && gameState.possibleMoves && gameState.possibleMoves[square] 
        ? { square } // This is a piece that can move
        : null;
        
    // If the user clicked a square containing a movable piece of their color, select it
    if (piece && gameState.possibleMoves[square]?.length > 0) {
      selectSquare(square);
      return;
    }
    
    // If a piece is already selected, try to move it to the clicked square
    if (gameState.selectedSquare) {
      // Check if this is a valid destination
      const validDestinations = gameState.possibleMoves[gameState.selectedSquare] || [];
      
      if (validDestinations.includes(square)) {
        // Valid move - execute it
        makeMove({
          from: gameState.selectedSquare,
          to: square,
          // Add promotion to queen if this is a pawn reaching the last rank
          promotion: 'q'
        });
      } else {
        // Invalid destination, deselect
        selectSquare(null);
      }
    }
  };
  
  const handleOfferDraw = () => {
    offerDraw();
    toast({
      title: "Draw Offered",
      description: "You offered a draw to your opponent."
    });
  };
  
  const handleResign = () => {
    resignGame();
    toast({
      title: "Game Resigned",
      description: "You resigned the game.",
      variant: "destructive"
    });
    onExit();
  };
  
  const handleGameMenu = () => {
    toast({
      title: "Game Menu",
      description: "Game menu will be implemented soon."
    });
  };
  
  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  // Show loading screen for a short time only, then continue with the game
  // even if some data is missing - we'll use defaults
  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-white z-40 flex flex-col items-center justify-center">
        <div className="w-16 h-16 mb-4 loading-knight">
          <svg className="w-full h-full text-primary" viewBox="0 0 45 45">
            <g fill="none" fillRule="evenodd" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 10c10.5 1 16.5 8 16 29H15c0-9 10-6.5 8-21" fill="currentColor"/>
              <path d="M24 18c.38 2.91-5.55 7.37-8 9-3 2-2.82 4.34-5 4-1.042-.94 1.41-3.04 0-3-1 0 .19 1.23-1 2-1 0-4.003 1-4-4 0-2 6-12 6-12s1.89-1.9 2-3.5c-.73-.994-.5-2-.5-3 1-1 3 2.5 3 2.5h2s.78-1.992 2.5-3c1 0 1 3 1 3" fill="currentColor"/>
            </g>
          </svg>
        </div>
        <p>Loading game...</p>
      </div>
    );
  }
  
  // Initialize default values if data is missing
  const gameDataDefault = { 
    white: { username: 'You', rating: 1200 },
    black: { username: 'Opponent', rating: 1200 },
    timeControl: 'blitz'
  };
  
  // Safely access game data
  const safeGameData = gameData || gameDataDefault;
  
  // Reference for tracking if we've initialized the game
  const gameInitializedRef = React.useRef(false);
  
  // Use useEffect to initialize the game state only once
  useEffect(() => {
    if (!gameState && !gameInitializedRef.current) {
      // Mark as initialized to prevent multiple attempts
      gameInitializedRef.current = true;
      
      try {
        // Make sure we have a selected square set to null
        selectSquare(null);
      } catch (error) {
        console.error("Error initializing game:", error);
      }
    }
  }, [gameState, selectSquare]);
  
  // Separate effect for making the initial move
  useEffect(() => {
    if (!gameState && gameInitializedRef.current) {
      const timer = setTimeout(() => {
        try {
          // Try to make a move to trigger game start
          makeMove({ from: 'e2', to: 'e4' });
        } catch (error) {
          console.error("Error making initial move:", error);
        }
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [gameState, makeMove]);
  
  // Use safe game data for player information
  const { white, black } = safeGameData;
  
  return (
    <div className="fixed inset-0 bg-white z-40">
      <header className="bg-primary px-5 py-3 flex justify-between items-center">
        <button className="text-white" onClick={onExit}>
          <X className="h-6 w-6" />
        </button>
        <div className="text-white font-heading">
          {safeGameData.timeControl === 'blitz' ? 'Blitz Match' : 
           safeGameData.timeControl === 'rapid' ? 'Rapid Match' : 
           safeGameData.timeControl === 'classical' ? 'Classical Match' : 'Custom Match'}
        </div>
        <button className="text-white" onClick={handleGameMenu}>
          <MoreVertical className="h-6 w-6" />
        </button>
      </header>

      <div className="p-4 bg-gradient-to-b from-gray-50 to-gray-100">
        <div className="flex justify-between items-center mb-4 bg-white p-3 rounded-lg shadow-sm">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-accent text-white overflow-hidden mr-3 shadow-inner">
              <div className="w-full h-full flex items-center justify-center font-semibold">
                {black?.username?.charAt(0).toUpperCase() || '?'}
              </div>
            </div>
            <div>
              <p className="font-semibold text-base">{black?.username || 'Opponent'}</p>
              <p className="text-sm text-gray-600">Rating: {black?.rating || '----'}</p>
            </div>
          </div>
          <div className="bg-secondary text-white py-2 px-4 rounded-lg font-mono text-lg shadow-sm">
            {formatTime(timeLeft.black)}
          </div>
        </div>

        {/* Chess Board */}
        {gameState ? (
          <ChessBoard 
            fen={gameState.fen}
            flipped={gameData?.color === 'black'}
            lastMove={lastMove}
            possibleMoves={gameState.possibleMoves}
            onSquareClick={handleSquareClick}
          />
        ) : (
          <div className="w-full aspect-square flex items-center justify-center bg-gray-100 rounded-lg">
            <p>Loading chess board...</p>
          </div>
        )}

        <div className="flex justify-between items-center mt-3">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-accent overflow-hidden mr-2">
              <div className="w-full h-full flex items-center justify-center text-white">
                {white?.username?.charAt(0).toUpperCase() || '?'}
              </div>
            </div>
            <div>
              <p className="font-medium text-sm">{white?.username || 'You'}</p>
              <p className="text-xs text-gray-600">{white?.rating || '----'}</p>
            </div>
          </div>
          <div className="bg-highlight text-white py-1 px-3 rounded font-mono">
            {formatTime(timeLeft.white)}
          </div>
        </div>
      </div>

      <div className="bg-white p-4 border-t border-gray-200">
        <div className="flex justify-between gap-4">
          <button 
            className="flex-1 bg-accent hover:bg-accent/90 text-white py-3 px-6 rounded-lg text-base font-semibold transition-colors shadow-sm"
            onClick={handleOfferDraw}
            disabled={gameState?.isGameOver || !gameState}
          >
            Offer Draw
          </button>
          <button 
            className="flex-1 bg-red-500 hover:bg-red-600 text-white py-3 px-6 rounded-lg text-base font-semibold transition-colors shadow-sm"
            onClick={handleResign}
            disabled={gameState?.isGameOver || !gameState}
          >
            Resign
          </button>
        </div>
      </div>
    </div>
  );
};

export default GameBoard;
