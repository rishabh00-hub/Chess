import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import LoadingScreen from "@/components/LoadingScreen";
import BottomNavigation from "@/components/BottomNavigation";
import Home from './pages/Home';
import Play from './pages/Play';
import Statistics from './pages/Statistics';
import Leaderboard from './pages/Leaderboard';
import History from './pages/History';
import Tutorial from "@/pages/Tutorial";
import NotFound from './pages/not-found';
import { queryClient } from "./lib/queryClient";
import { useState, useEffect } from "react";
import { initializeTelegramWebApp } from "./lib/telegramWebApp";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/play" component={Play} />
      <Route path="/stats" component={Statistics} />
      <Route path="/leaderboard" component={Leaderboard} />
      <Route path="/history" component={History} />
      <Route path="/tutorial" component={Tutorial} />
      <Route path="/:rest*" component={NotFound} />
    </Switch>
  );
}

function App() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Initialize Telegram Web App
    try {
      initializeTelegramWebApp();
      console.log('Telegram Web App initialized');
    } catch (error) {
      console.error('Failed to initialize Telegram Web App:', error);
    }

    // Simulate loading assets
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <TooltipProvider>
      <Toaster />
      {loading ? (
        <LoadingScreen />
      ) : (
        <div className="relative min-h-screen max-w-lg mx-auto bg-white shadow-lg">
          <div className="pb-16">
            <Router />
          </div>
          <BottomNavigation />
        </div>
      )}
    </TooltipProvider>
  );
}

export default App;