import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useUser } from '@/context/UserContext';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import GameBoard from '@/components/GameBoard';
import { CloudLightning, Users, Bot, Coins } from 'lucide-react';
import { queryClient } from '@/lib/queryClient';

const Play = () => {
  const { user } = useUser();
  const { toast } = useToast();
  const [selectedTimeControl] = useState('blitz');
  const [activeGame, setActiveGame] = useState<number | null>(null);
  
  // Fetch active games
  const { data: activeGames, isLoading: gamesLoading } = useQuery({
    queryKey: ['/api/games/active'],
    retry: false,
  });
  
  // Create new game mutation
  const createGameMutation = useMutation({
    mutationFn: async (gameData: {
      mode: string;
      timeControl: string;
    }) => {
      try {
        return await apiRequest('POST', '/api/games', {
          whiteId: 1, // Current user (hardcoded for demo)
          blackId: 2, // Opponent (hardcoded for demo)
          timeControl: gameData.timeControl,
          mode: gameData.mode,
          isRated: true,
          bettingAmount: gameData.mode === 'betting' ? 5 : null
        });
      } catch (error) {
        // For local development, create a mock game without API
        console.log("Creating local game instead");
        return { id: Math.floor(Math.random() * 10000) };
      }
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/games/active'] });
      toast({
        title: "Game Created",
        description: "Your new game has been created!"
      });
      
      // Automatically start the new game
      handleResumeGame(data.id);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Could not create game: ${error.message}`,
        variant: "destructive"
      });
      
      // For development, create a local game even on error
      const fakeGameId = Math.floor(Math.random() * 10000);
      handleResumeGame(fakeGameId);
    }
  });
  
  const handlePlayMode = (mode: string) => {
    createGameMutation.mutate({
      mode,
      timeControl: selectedTimeControl
    });
  };
  
  // Time control handler removed
  
  const handleResumeGame = (gameId: number) => {
    console.log("Resuming game:", gameId);
    setActiveGame(gameId);
    
    // Inform user the game is starting
    toast({
      title: "Game Starting",
      description: "Your game is being initialized..."
    });
  };
  
  const handleExitGame = () => {
    setActiveGame(null);
  };
  
  const handleResignGame = (gameId: number) => {
    toast({
      title: "Game Resigned",
      description: "You have resigned the game.",
      variant: "destructive"
    });
  };
  
  // If there's an active game being played, show the game board
  if (activeGame !== null) {
    return <GameBoard gameId={activeGame} onExit={handleExitGame} />;
  }
  
  // Time controls array removed
  
  return (
    <div className="page pb-20">
      <header className="bg-primary px-5 py-6 shadow-md">
        <h1 className="text-white text-xl font-heading font-bold">Play Chess</h1>
      </header>

      <section className="px-5 py-6">
        <div className="grid grid-cols-2 gap-4 mb-8">
          <button 
            className="bg-secondary hover:bg-secondary-light text-white rounded-lg p-4 text-left transition-colors" 
            onClick={() => handlePlayMode('quick')}
            disabled={createGameMutation.isPending}
          >
            <div className="text-3xl mb-2">
              <CloudLightning className="h-8 w-8" />
            </div>
            <h3 className="font-heading font-semibold">Quick Match</h3>
            <p className="text-xs text-gray-300 mt-1">Play against random opponent</p>
          </button>
          
          <button 
            className="bg-secondary hover:bg-secondary-light text-white rounded-lg p-4 text-left transition-colors" 
            onClick={() => handlePlayMode('friend')}
            disabled={createGameMutation.isPending}
          >
            <div className="text-3xl mb-2">
              <Users className="h-8 w-8" />
            </div>
            <h3 className="font-heading font-semibold">Play Friend</h3>
            <p className="text-xs text-gray-300 mt-1">Challenge a friend to play</p>
          </button>
          
          <button 
            className="bg-secondary hover:bg-secondary-light text-white rounded-lg p-4 text-left transition-colors" 
            onClick={() => handlePlayMode('computer')}
            disabled={createGameMutation.isPending}
          >
            <div className="text-3xl mb-2">
              <Bot className="h-8 w-8" />
            </div>
            <h3 className="font-heading font-semibold">Computer</h3>
            <p className="text-xs text-gray-300 mt-1">Play against AI opponent</p>
          </button>
          
          <button 
            className="bg-secondary hover:bg-secondary-light text-white rounded-lg p-4 text-left transition-colors" 
            onClick={() => handlePlayMode('betting')}
            disabled={createGameMutation.isPending}
          >
            <div className="text-3xl mb-2">
              <Coins className="h-8 w-8" />
            </div>
            <h3 className="font-heading font-semibold">Coin Match</h3>
            <p className="text-xs text-gray-300 mt-1">Bet coins on your victory</p>
          </button>
        </div>

        {/* Time controls section removed */}

        <div>
          <h3 className="font-heading font-semibold text-lg mb-4">Active Games</h3>
          <div className="space-y-3">
            {gamesLoading ? (
              <div className="p-4 text-center">Loading active games...</div>
            ) : activeGames && activeGames.length > 0 ? (
              activeGames.map((game) => (
                <div key={game.id} className="bg-gray-50 rounded-lg p-4 shadow-sm">
                  <div className="flex justify-between items-center mb-3">
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-full bg-gray-200 overflow-hidden mr-3">
                        <div className="w-full h-full flex items-center justify-center">
                          {game.opponent?.username?.charAt(0).toUpperCase() || '?'}
                        </div>
                      </div>
                      <div>
                        <p className="font-semibold">
                          {game.opponent?.username || 'Opponent'} 
                          {game.opponent?.rating ? ` (${game.opponent.rating})` : ''}
                        </p>
                        <p className="text-xs text-gray-500">
                          {game.timeControl === 'blitz' ? 'Blitz' : 
                           game.timeControl === 'rapid' ? 'Rapid' : 
                           game.timeControl === 'classical' ? 'Classical' : 'Custom'} • 
                           Started {new Date(game.startTime).toLocaleString(undefined, { 
                             dateStyle: 'short', 
                             timeStyle: 'short' 
                           })}
                        </p>
                      </div>
                    </div>
                    <div className="text-xs bg-yellow-100 text-yellow-800 py-1 px-2 rounded">
                      Your turn
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <button 
                      className="text-accent text-sm font-medium" 
                      onClick={() => handleResumeGame(game.id)}
                    >
                      Resume game
                    </button>
                    <button 
                      className="text-red-500 text-sm font-medium" 
                      onClick={() => handleResignGame(game.id)}
                    >
                      Resign
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-gray-50 rounded-lg p-4 text-center">
                No active games. Start a new game!
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Play;
