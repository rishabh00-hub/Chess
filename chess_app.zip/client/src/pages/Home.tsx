
import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { CheckSquare, Clock, Share, Award, User, Wallet, Coins, X } from 'lucide-react';
import { useUser } from '@/context/UserContext';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';

const Home = () => {
  const { user } = useUser();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [level, setLevel] = useState(1);
  const [experience, setExperience] = useState(0);
  const [maxExperience, setMaxExperience] = useState(10);
  const [showCoinHistory, setShowCoinHistory] = useState(false);
  
  // Mock coin history data - this would come from an API in a real app
  const [coinHistory] = useState([
    { id: 1, amount: 5, type: 'earned', description: 'Won match against BobMaster', date: '2025-05-20' },
    { id: 2, amount: 10, type: 'earned', description: 'Daily challenge completed', date: '2025-05-19' },
    { id: 3, amount: 20, type: 'deposit', description: 'External wallet transfer', date: '2025-05-18' },
    { id: 4, amount: -5, type: 'spent', description: 'Entry fee for tournament', date: '2025-05-15' },
  ]);

  useEffect(() => {
    if (user) {
      setLevel(user.level || 1);
      setExperience(user.experience || 0);
      // Each level requires more experience
      setMaxExperience((user.level || 1) * 10);
    }
  }, [user]);
  
  const handleTaskClick = () => {
    toast({
      title: "Tasks",
      description: "Daily tasks feature will be available soon!"
    });
  };
  
  const handleHistoryClick = () => {
    toast({
      title: "Game History",
      description: "View your game history and replays soon!"
    });
  };
  
  const handleReferClick = () => {
    toast({
      title: "Refer Friends",
      description: "Share with friends and earn coins!"
    });
  };
  
  const handleProfileClick = () => {
    toast({
      title: "User Profile",
      description: "Profile settings will be available soon!"
    });
  };
  
  const handleDailyChallengeClick = () => {
    toast({
      title: "Daily Challenge",
      description: "Starting today's challenge..."
    });
    // Navigate to the challenge page or start the challenge
  };
  
  const progressPercentage = Math.min(100, Math.round((experience / maxExperience) * 100));

  return (
    <div className="pb-20">
      <header className="bg-primary px-5 py-6 shadow-md">
        <div className="flex justify-between items-center">
          <h1 className="text-white text-2xl font-heading font-bold">NoT_Chess</h1>
          <button 
            onClick={handleProfileClick}
            className="flex items-center transition-transform hover:scale-105"
          >
            <div className="w-10 h-10 rounded-full bg-accent overflow-hidden mr-2">
              <div className="w-full h-full flex items-center justify-center text-white">
                {user?.username?.charAt(0).toUpperCase() || 'A'}
              </div>
            </div>
            <span className="text-white font-medium">{user?.username || 'AlexKnight'}</span>
          </button>
        </div>

        <div className="mt-4 flex items-center bg-white/10 rounded-lg p-3">
          <Award className="text-white mr-2 h-5 w-5" />
          <div className="flex-1">
            <div className="w-full bg-white/20 rounded-full h-2">
              <div 
                className="bg-accent h-full rounded-full transition-all duration-500" 
                style={{ width: `${progressPercentage}%` }}
              ></div>
            </div>
            <div className="flex justify-between text-white text-sm mt-1">
              <span>Level {level}</span>
              <span>{experience}/{maxExperience} XP</span>
            </div>
          </div>
        </div>
        
        <div className="mt-3">
          <button 
            onClick={() => setShowCoinHistory(true)}
            className="w-full bg-white/10 rounded-lg p-3 flex items-center justify-between hover:bg-white/15 transition-colors"
          >
            <div className="flex items-center">
              <Coins className="text-yellow-400 mr-2 h-5 w-5" />
              <span className="text-white font-medium">Total Coins</span>
            </div>
            <span className="text-yellow-400 font-bold">{user?.coins || 0}</span>
          </button>
        </div>
      </header>

      <main className="px-5 py-6">
        <div className="flex justify-between mb-8">
          <div className="space-y-4">
            <button 
              className="flex items-center space-x-2 text-gray-700 hover:text-accent transition-colors"
              onClick={handleTaskClick}
            >
              <CheckSquare className="h-6 w-6" />
              <span className="font-medium">Tasks</span>
            </button>

            <button 
              className="flex items-center space-x-2 text-gray-700 hover:text-accent transition-colors"
              onClick={() => setLocation('/history')}
            >
              <Clock className="h-6 w-6" />
              <span className="font-medium">History</span>
            </button>
          </div>

          <button 
            className="flex items-center space-x-2 text-gray-700 hover:text-accent transition-colors h-fit"
            onClick={handleReferClick}
          >
            <Share className="h-6 w-6" />
            <span className="font-medium">Refer</span>
          </button>
        </div>

        <div className="space-y-4">
          <div 
            className="bg-gray-50 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
            onClick={handleDailyChallengeClick}
          >
            <h3 className="font-heading font-semibold mb-2">Daily Challenge</h3>
            <p className="text-gray-600">Complete today's puzzle to earn rewards!</p>
            <div className="mt-2 text-xs bg-green-100 text-green-800 py-1 px-2 rounded-full inline-block">
              + 5 XP & 2 Coins
            </div>
          </div>
        </div>

        <div className="fixed bottom-20 right-5">
          <button 
            className="bg-accent hover:bg-accent/90 text-white p-4 rounded-full shadow-lg"
            onClick={() => toast({
              title: "Wallet",
              description: "Wallet feature will be available soon!"
            })}
          >
            <Wallet className="h-6 w-6" />
          </button>
        </div>
      </main>
      
      {/* Coin History Modal */}
      {showCoinHistory && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-md max-h-[80vh] overflow-hidden flex flex-col">
            <div className="p-4 bg-primary flex items-center justify-between">
              <h2 className="text-white text-lg font-bold">Coin History</h2>
              <button 
                onClick={() => setShowCoinHistory(false)}
                className="text-white hover:text-gray-300"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="p-4 flex items-center justify-between bg-gray-100">
              <span className="font-semibold">Total Balance</span>
              <span className="font-bold text-yellow-600 flex items-center">
                <Coins className="h-5 w-5 mr-1" /> {user?.coins || 0}
              </span>
            </div>
            
            <div className="overflow-y-auto flex-1">
              {coinHistory.length > 0 ? (
                <div className="divide-y">
                  {coinHistory.map((item) => (
                    <div key={item.id} className="p-4 hover:bg-gray-50">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-medium">{item.description}</p>
                          <p className="text-sm text-gray-500">{item.date}</p>
                        </div>
                        <span className={`font-bold ${
                          item.type === 'earned' || item.type === 'deposit' 
                            ? 'text-green-600' 
                            : 'text-red-600'
                        }`}>
                          {(item.type === 'earned' || item.type === 'deposit') ? '+' : ''}
                          {item.amount}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center text-gray-500">
                  <p>No coin transactions yet</p>
                </div>
              )}
            </div>
            
            <div className="p-4 border-t">
              <button 
                onClick={() => setShowCoinHistory(false)}
                className="w-full py-2 rounded-lg bg-primary text-white font-medium hover:bg-primary-light transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Home;
