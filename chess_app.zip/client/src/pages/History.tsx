
import { useQuery } from '@tanstack/react-query';
import { useUser } from '@/context/UserContext';
import { ArrowLeft, Award } from 'lucide-react';
import { useLocation } from 'wouter';

const History = () => {
  const { user } = useUser();
  const [, setLocation] = useLocation();
  
  // Fetch game history data
  const { data: gameHistory, isLoading } = useQuery({
    queryKey: ['/api/games/history'],
    retry: false,
  });

  return (
    <div className="page pb-20">
      <header className="bg-primary px-5 py-6 shadow-md flex items-center">
        <button 
          onClick={() => setLocation('/')} 
          className="mr-2 text-white"
        >
          <ArrowLeft className="h-6 w-6" />
        </button>
        <h1 className="text-white text-xl font-heading font-bold">Game History</h1>
      </header>

      <main className="px-5 py-6">
        {isLoading ? (
          <div className="flex justify-center items-center h-40">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-accent"></div>
          </div>
        ) : gameHistory && gameHistory.length > 0 ? (
          <div className="space-y-4">
            {gameHistory.map((game) => (
              <div key={game.id} className="bg-white rounded-lg shadow-md p-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-gray-200 overflow-hidden mr-3 flex items-center justify-center">
                      {game.opponent?.username?.charAt(0).toUpperCase() || '?'}
                    </div>
                    <div>
                      <p className="font-semibold">
                        {game.opponent?.username || 'Opponent'} 
                        {game.opponent?.rating ? ` (${game.opponent.rating})` : ''}
                      </p>
                      <p className="text-xs text-gray-500">
                        {new Date(game.endTime).toLocaleString(undefined, {
                          dateStyle: 'short', 
                          timeStyle: 'short'
                        })}
                      </p>
                    </div>
                  </div>
                  <div className={`flex items-center ${
                    game.outcome === 'win' ? 'text-green-500' : 
                    game.outcome === 'loss' ? 'text-red-500' : 'text-yellow-500'
                  }`}>
                    {game.outcome === 'win' && (
                      <>
                        <Award className="h-5 w-5 mr-1" />
                        <span className="font-semibold">Win</span>
                      </>
                    )}
                    {game.outcome === 'loss' && <span className="font-semibold">Loss</span>}
                    {game.outcome === 'draw' && <span className="font-semibold">Draw</span>}
                  </div>
                </div>
                
                <div className="mt-2 flex justify-between items-center">
                  <div>
                    <span className="text-xs bg-gray-100 rounded-full px-2 py-1">
                      {game.timeControl === 'blitz' ? 'Blitz' : 
                      game.timeControl === 'rapid' ? 'Rapid' : 
                      game.timeControl === 'classical' ? 'Classical' : 'Custom'}
                    </span>
                    <span className="text-xs bg-gray-100 rounded-full px-2 py-1 ml-2">
                      {game.color === 'white' ? 'White' : 'Black'}
                    </span>
                  </div>
                  <div className="text-xs">
                    {game.outcome === 'win' && <span className="text-green-500">+4</span>}
                    {game.outcome === 'loss' && <span className="text-red-500">-2</span>}
                    {game.outcome === 'draw' && <span className="text-yellow-500">+2</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg p-6 text-center">
            <p className="text-gray-500">No game history yet</p>
            <button 
              className="mt-4 px-4 py-2 bg-accent text-white rounded-lg"
              onClick={() => setLocation('/play')}
            >
              Start Playing
            </button>
          </div>
        )}
      </main>
    </div>
  );
};

export default History;
