import { useUser } from '@/context/UserContext';
import { useQuery } from '@tanstack/react-query';
import { 
  BarChart as BarChartIcon, 
  LineChart, 
  PieChart
} from 'lucide-react';
import { useState } from 'react';
import {
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  Line,
  LineChart as RechartsLineChart,
  ResponsiveContainer
} from 'recharts';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';

const Statistics = () => {
  const { user } = useUser();
  const [activeGraph, setActiveGraph] = useState<'wins' | 'losses' | 'draws'>('wins');

  // Fetch user game history
  const { data: gameHistory = [] } = useQuery({
    queryKey: ['/api/games/history'],
    retry: false,
  });

  // Calculate stats from game history
  const calculateStats = () => {
    if (!gameHistory || gameHistory.length === 0) {
      return {
        totalGames: 0,
        wins: 0,
        losses: 0,
        draws: 0,
        winRate: 0
      };
    }

    const wins = gameHistory.filter(game => game.outcome === 'win').length;
    const losses = gameHistory.filter(game => game.outcome === 'loss').length;
    const draws = gameHistory.filter(game => game.outcome === 'draw').length;
    const totalGames = gameHistory.length;
    const winRate = totalGames > 0 ? Math.round((wins / totalGames) * 100) : 0;

    return {
      totalGames,
      wins,
      losses,
      draws,
      winRate
    };
  };

  const stats = calculateStats();

  // Prepare data for XY graph
  const prepareGraphData = () => {
    // If no game history, create sample data
    if (!gameHistory || gameHistory.length === 0) {
      return Array.from({ length: 10 }, (_, i) => ({
        gameNumber: i + 1,
        wins: Math.floor(Math.random() * 8),
        losses: Math.floor(Math.random() * 5),
        draws: Math.floor(Math.random() * 3)
      }));
    }

    // Create cumulative data
    let winsCount = 0;
    let lossesCount = 0;
    let drawsCount = 0;

    return gameHistory.map((game, index) => {
      if (game.outcome === 'win') winsCount++;
      if (game.outcome === 'loss') lossesCount++;
      if (game.outcome === 'draw') drawsCount++;

      return {
        gameNumber: index + 1,
        wins: winsCount,
        losses: lossesCount,
        draws: drawsCount
      };
    });
  };

  const graphData = prepareGraphData();

  // Placeholder data for weekly ratings and playing style
  const weeklyRatings = [40, 65, 45, 35, 50, 75, 40];
  const playingStyle = {
    aggressive: 75,
    openingKnowledge: 60,
    endgameSkills: 45,
    tacticalVision: 65
  };

  return (
    <div className="page pb-20">
      <header className="bg-primary px-5 py-6 shadow-md">
        <h1 className="text-white text-xl font-heading font-bold">Your Statistics</h1>
      </header>

      <section className="px-5 py-6">
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <h2 className="font-heading font-semibold text-lg mb-3">Performance Overview</h2>
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div className="bg-gray-50 p-3 rounded-md text-center">
              <p className="text-xs text-gray-500 mb-1">Rating</p>
              <p className="text-xl font-mono font-semibold">{user?.rating || '---'}</p>
            </div>
            <div className="bg-gray-50 p-3 rounded-md text-center">
              <p className="text-xs text-gray-500 mb-1">Win Rate</p>
              <p className="text-xl font-mono font-semibold">{stats.winRate}%</p>
            </div>
            <div className="bg-gray-50 p-3 rounded-md text-center">
              <p className="text-xs text-gray-500 mb-1">Games</p>
              <p className="text-xl font-mono font-semibold">{stats.totalGames}</p>
            </div>
          </div>

          <div className="h-40 bg-gray-50 rounded-md p-3 mb-3">
            {/* Chart representation */}
            <div className="h-full flex items-end justify-between">
              {weeklyRatings.map((height, index) => (
                <div 
                  key={index} 
                  className={`w-8 rounded-t ${index === 5 ? 'bg-highlight' : 'bg-accent'}`} 
                  style={{ height: `${height}%` }}
                ></div>
              ))}
            </div>
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>Mon</span>
              <span>Tue</span>
              <span>Wed</span>
              <span>Thu</span>
              <span>Fri</span>
              <span>Sat</span>
              <span>Sun</span>
            </div>
          </div>
          <p className="text-xs text-gray-500">Rating changes over last 7 days</p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <h2 className="font-heading font-semibold text-lg mb-3">Game Results</h2>

          {/* Toggle Group for switching between graphs */}
          <div className="flex justify-center mb-4">
            <ToggleGroup type="single" value={activeGraph} onValueChange={(value) => value && setActiveGraph(value as 'wins' | 'losses' | 'draws')}>
              <ToggleGroupItem value="wins" aria-label="Show wins" className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                <span>Wins</span>
              </ToggleGroupItem>
              <ToggleGroupItem value="losses" aria-label="Show losses" className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                <span>Losses</span>
              </ToggleGroupItem>
              <ToggleGroupItem value="draws" aria-label="Show draws" className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></div>
                <span>Draws</span>
              </ToggleGroupItem>
            </ToggleGroup>
          </div>

          {/* XY Graph */}
          <div className="w-full h-64 mb-4">
            <ResponsiveContainer width="100%" height="100%">
              <RechartsLineChart data={graphData} margin={{ top: 5, right: 5, left: 0, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="gameNumber" 
                  label={{ value: 'Total Matches', position: 'bottom', offset: 0 }}
                />
                <YAxis 
                  label={{ value: 'Count', angle: -90, position: 'insideLeft' }} 
                />
                <Tooltip />
                <Legend />
                {activeGraph === 'wins' && (
                  <Line 
                    type="monotone" 
                    dataKey="wins" 
                    stroke="#4CAF50" 
                    strokeWidth={2} 
                    dot={{ r: 3 }} 
                    activeDot={{ r: 5 }}
                  />
                )}
                {activeGraph === 'losses' && (
                  <Line 
                    type="monotone" 
                    dataKey="losses" 
                    stroke="#F44336" 
                    strokeWidth={2} 
                    dot={{ r: 3 }} 
                    activeDot={{ r: 5 }}
                  />
                )}
                {activeGraph === 'draws' && (
                  <Line 
                    type="monotone" 
                    dataKey="draws" 
                    stroke="#FFC107" 
                    strokeWidth={2} 
                    dot={{ r: 3 }} 
                    activeDot={{ r: 5 }}
                  />
                )}
              </RechartsLineChart>
            </ResponsiveContainer>
          </div>

          {/* Statistics Summary */}
          <div className="flex">
            <div className="flex-1">
              <div className="flex items-center mb-2">
                <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Wins</p>
                </div>
                <p className="font-mono">{stats.wins}</p>
              </div>
              <div className="flex items-center mb-2">
                <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Draws</p>
                </div>
                <p className="font-mono">{stats.draws}</p>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Losses</p>
                </div>
                <p className="font-mono">{stats.losses}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-4">
          <h2 className="font-heading font-semibold text-lg mb-3">Playing Style</h2>
          <div className="space-y-3">
            {Object.entries(playingStyle).map(([key, value]) => (
              <div key={key}>
                <div className="flex justify-between text-sm mb-1">
                  <span>{key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}</span>
                  <span>{value}%</span>
                </div>
                <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className="bg-accent h-full rounded-full" 
                    style={{ width: `${value}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Statistics;