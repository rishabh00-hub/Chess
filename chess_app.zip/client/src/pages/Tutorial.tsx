
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import ChessBoard from '@/components/ChessBoard';
import { Chess } from '@/lib/chess';

const Tutorial = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('basic');
  
  // Create a chess instance for different positions
  const puzzleChess = new Chess('r1bqkb1r/pppp1Qpp/2n2n2/4p3/2B1P3/8/PPPP1PPP/RNB1K1NR b KQkq - 0 4');
  const openingChess = new Chess('rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1');
  const middleGameChess = new Chess('r1bq1rk1/ppp2ppp/2np1n2/2b1p3/2B1P3/2NP1N2/PPP2PPP/R1BQ1RK1 w - - 0 8');
  const endGameChess = new Chess('4k3/8/4K3/8/8/8/4P3/8 w - - 0 1');
  
  const tabs = [
    { id: 'basic', label: 'Basic Rules' },
    { id: 'openings', label: 'Openings' },
    { id: 'middlegame', label: 'Middle Game' },
    { id: 'endgame', label: 'End Game' }
  ];
  
  const chessPieces = [
    { type: 'p', name: 'Pawn', description: 'Moves forward one square, but captures diagonally. On its first move, a pawn can move two squares forward. Can be promoted to any piece (except king) when it reaches the last rank.' },
    { type: 'n', name: 'Knight', description: 'Moves in an L-shape: two squares in one direction and then one square perpendicular. Knights can jump over other pieces, making them valuable for tactical maneuvers.' },
    { type: 'b', name: 'Bishop', description: 'Moves diagonally any number of squares. Cannot jump over other pieces. Each bishop is confined to squares of only one color, either light or dark.' },
    { type: 'r', name: 'Rook', description: 'Moves horizontally or vertically any number of squares. Cannot jump over other pieces. Very powerful in open positions and endgames.' },
    { type: 'q', name: 'Queen', description: 'Combines the power of the rook and bishop, moving any number of squares diagonally, horizontally, or vertically. The most powerful piece on the board.' },
    { type: 'k', name: 'King', description: 'Moves one square in any direction. The king can also perform a special move called castling with a rook. Must be protected at all times - if your king is in checkmate, you lose the game.' }
  ];
  
  const openings = [
    { 
      id: 'e4', 
      name: 'King\'s Pawn Opening (1.e4)', 
      description: 'One of the most common first moves, controlling the center and opening lines for the bishop and queen.', 
      followups: ['Sicilian Defense (1...c5)', 'French Defense (1...e6)', 'Caro-Kann (1...c6)']
    },
    { 
      id: 'd4', 
      name: 'Queen\'s Pawn Opening (1.d4)', 
      description: 'Controls the center and opens up the diagonal for the queen\'s bishop.', 
      followups: ['Queen\'s Gambit (1...d5 2.c4)', 'Indian Defenses (1...Nf6)']
    },
    { 
      id: 'italian', 
      name: 'Italian Game', 
      description: 'After 1.e4 e5 2.Nf3 Nc6 3.Bc4, developing the bishop to a powerful diagonal targeting f7.', 
      followups: ['Giuoco Piano', 'Two Knights Defense']
    },
    { 
      id: 'ruy', 
      name: 'Ruy Lopez', 
      description: 'After 1.e4 e5 2.Nf3 Nc6 3.Bb5, putting pressure on the knight defending e5.', 
      followups: ['Berlin Defense', 'Morphy Defense', 'Marshall Attack']
    }
  ];
  
  const middleGameStrategies = [
    { 
      id: 'piece', 
      name: 'Piece Development', 
      description: 'Get all your pieces into the game, especially the minor pieces (knights and bishops) before launching attacks.' 
    },
    { 
      id: 'center', 
      name: 'Control the Center', 
      description: 'The four central squares (d4, d5, e4, e5) are crucial. Controlling them gives your pieces more mobility and options.' 
    },
    { 
      id: 'king', 
      name: 'King Safety', 
      description: 'Castle early to protect your king. Consider the pawn structure in front of your castled king.' 
    },
    { 
      id: 'tactics', 
      name: 'Tactical Patterns', 
      description: 'Look for forks, pins, skewers, discovered attacks, and other tactical motifs to gain material or positional advantage.' 
    }
  ];
  
  const endGamePrinciples = [
    { 
      id: 'king', 
      name: 'Activate Your King', 
      description: 'Unlike the middlegame, the king becomes a strong piece in the endgame and should be centralized.' 
    },
    { 
      id: 'pawns', 
      name: 'Pawn Structure', 
      description: 'Connected passed pawns are very strong. Isolated and doubled pawns are weaknesses.' 
    },
    { 
      id: 'promotion', 
      name: 'Pawn Promotion', 
      description: 'Getting a pawn to the eighth rank to promote to a queen is often decisive.' 
    },
    { 
      id: 'opposition', 
      name: 'Opposition', 
      description: 'In king and pawn endgames, the concept of opposition (kings facing each other with one square between) is crucial.' 
    }
  ];
  
  const checkmates = [
    { 
      id: 'back', 
      name: 'Back Rank Mate', 
      description: 'When the king is trapped by its own pieces and a rook or queen delivers mate along the back rank.' 
    },
    { 
      id: 'smothered', 
      name: 'Smothered Mate', 
      description: 'A knight delivers checkmate to a king that is completely surrounded by its own pieces.' 
    },
    { 
      id: 'scholars', 
      name: 'Scholar\'s Mate', 
      description: 'A quick checkmate targeting the f7 square (1.e4 e5 2.Qh5 Nc6 3.Bc4 Nf6?? 4.Qxf7#).' 
    },
    { 
      id: 'anastasia', 
      name: 'Anastasia\'s Mate', 
      description: 'A knight and rook/queen cooperate to trap the king against the edge of the board.' 
    }
  ];
  
  const lessons = [
    { id: 'basics', title: 'Basics of Chess', description: 'Learn how to set up the board and basic rules' },
    { id: 'openings', title: 'Popular Openings', description: 'Master the first moves of your game' },
    { id: 'checkmates', title: 'Checkmate Patterns', description: 'Learn common ways to finish a game' },
    { id: 'tactics', title: 'Tactical Motifs', description: 'Discover forks, pins, and other tactical weapons' },
    { id: 'endgames', title: 'Essential Endgames', description: 'Master the crucial endgame techniques' }
  ];
  
  const puzzles = [
    { 
      id: 'puzzle1', 
      fen: 'r1bqkb1r/pppp1Qpp/2n2n2/4p3/2B1P3/8/PPPP1PPP/RNB1K1NR b KQkq - 0 4', 
      difficulty: 'Intermediate', 
      task: 'Black to move and save the game',
      solution: 'Qe7, blocking the check and protecting the rook'
    },
    { 
      id: 'puzzle2', 
      fen: '3r2k1/pp3ppp/2pr4/8/3P4/P1P5/1P3RPP/R5K1 w - - 0 1', 
      difficulty: 'Beginner',
      task: 'White to move and win material',
      solution: 'Rxf7, exploiting the pin on the g-file'
    }
  ];
  
  const handleViewPuzzleSolution = (solution) => {
    toast({
      title: "Puzzle Solution",
      description: solution
    });
  };
  
  const handleStartLesson = (lesson) => {
    // In a real implementation, this would load the lesson content
    toast({
      title: `Starting ${lesson}`,
      description: "Loading interactive lesson content..."
    });
  };
  
  const renderTabContent = () => {
    switch(activeTab) {
      case 'basic':
        return (
          <>
            <div className="bg-white rounded-lg shadow-md p-4 mb-6">
              <h2 className="font-heading font-semibold text-lg mb-3">Chess Pieces Movement</h2>
              <div className="space-y-4">
                {chessPieces.map(piece => (
                  <div key={piece.type} className="flex items-start">
                    <div className="w-12 h-12 flex items-center justify-center text-3xl mr-3">
                      {piece.type === 'p' ? '♟' : 
                       piece.type === 'n' ? '♞' : 
                       piece.type === 'b' ? '♝' : 
                       piece.type === 'r' ? '♜' : 
                       piece.type === 'q' ? '♛' : 
                       piece.type === 'k' ? '♚' : ''}
                    </div>
                    <div>
                      <h3 className="font-medium">{piece.name}</h3>
                      <p className="text-sm text-gray-600">{piece.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-4 mb-6">
              <h2 className="font-heading font-semibold text-lg mb-3">Basic Rules</h2>
              <div className="space-y-2">
                <div className="p-3 bg-gray-50 rounded-md">
                  <h3 className="font-medium">Objective</h3>
                  <p className="text-sm text-gray-600">Checkmate your opponent's king while protecting your own.</p>
                </div>
                <div className="p-3 bg-gray-50 rounded-md">
                  <h3 className="font-medium">Movement</h3>
                  <p className="text-sm text-gray-600">Each piece moves in a specific way. The player with white pieces moves first, then players alternate turns.</p>
                </div>
                <div className="p-3 bg-gray-50 rounded-md">
                  <h3 className="font-medium">Capturing</h3>
                  <p className="text-sm text-gray-600">When a piece moves to a square occupied by an opponent's piece, the opponent's piece is captured and removed from the board.</p>
                </div>
                <div className="p-3 bg-gray-50 rounded-md">
                  <h3 className="font-medium">Check & Checkmate</h3>
                  <p className="text-sm text-gray-600">A king is in check when it's threatened by an opponent's piece. The player must move out of check on their next move. Checkmate occurs when a king is in check and no legal move can escape the check.</p>
                </div>
                <div className="p-3 bg-gray-50 rounded-md">
                  <h3 className="font-medium">Special Moves</h3>
                  <p className="text-sm text-gray-600">Castling, en passant, and pawn promotion are special moves with unique rules.</p>
                </div>
              </div>
            </div>
          </>
        );
      case 'openings':
        return (
          <>
            <div className="bg-white rounded-lg shadow-md p-4 mb-6">
              <h2 className="font-heading font-semibold text-lg mb-3">Opening Principles</h2>
              <div className="space-y-2">
                <div className="p-3 bg-gray-50 rounded-md">
                  <h3 className="font-medium">Control the Center</h3>
                  <p className="text-sm text-gray-600">Occupy or control the central squares (e4, d4, e5, d5) with pawns and pieces.</p>
                </div>
                <div className="p-3 bg-gray-50 rounded-md">
                  <h3 className="font-medium">Develop Pieces</h3>
                  <p className="text-sm text-gray-600">Move your knights and bishops to active positions before moving your queen.</p>
                </div>
                <div className="p-3 bg-gray-50 rounded-md">
                  <h3 className="font-medium">King Safety</h3>
                  <p className="text-sm text-gray-600">Castle early to protect your king and connect your rooks.</p>
                </div>
                <div className="p-3 bg-gray-50 rounded-md">
                  <h3 className="font-medium">Don't Move Same Piece Twice</h3>
                  <p className="text-sm text-gray-600">In the opening, try to develop a new piece with each move rather than moving the same piece multiple times.</p>
                </div>
              </div>
            </div>
            
            <div className="w-full aspect-square mb-3 border border-gray-200 rounded-lg">
              <ChessBoard 
                fen={openingChess.fen()} 
                possibleMoves={{}} 
                onSquareClick={() => {}}
              />
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-4 mb-6">
              <h2 className="font-heading font-semibold text-lg mb-3">Popular Openings</h2>
              <div className="space-y-3">
                {openings.map(opening => (
                  <div key={opening.id} className="bg-gray-50 p-3 rounded-md">
                    <h3 className="font-medium">{opening.name}</h3>
                    <p className="text-sm text-gray-600 mt-1">{opening.description}</p>
                    <div className="mt-2">
                      <h4 className="text-xs font-medium text-gray-500">Common Responses:</h4>
                      <ul className="text-xs text-gray-600 list-disc list-inside">
                        {opening.followups.map((followup, index) => (
                          <li key={index}>{followup}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        );
      case 'middlegame':
        return (
          <>
            <div className="w-full aspect-square mb-3 border border-gray-200 rounded-lg">
              <ChessBoard 
                fen={middleGameChess.fen()} 
                possibleMoves={{}} 
                onSquareClick={() => {}}
              />
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-4 mb-6">
              <h2 className="font-heading font-semibold text-lg mb-3">Middle Game Strategies</h2>
              <div className="space-y-3">
                {middleGameStrategies.map(strategy => (
                  <div key={strategy.id} className="bg-gray-50 p-3 rounded-md">
                    <h3 className="font-medium">{strategy.name}</h3>
                    <p className="text-sm text-gray-600 mt-1">{strategy.description}</p>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-4 mb-6">
              <h2 className="font-heading font-semibold text-lg mb-3">Tactical Motifs</h2>
              <div className="space-y-3">
                <div className="bg-gray-50 p-3 rounded-md">
                  <h3 className="font-medium">Fork</h3>
                  <p className="text-sm text-gray-600">A piece attacks two or more enemy pieces simultaneously.</p>
                </div>
                <div className="bg-gray-50 p-3 rounded-md">
                  <h3 className="font-medium">Pin</h3>
                  <p className="text-sm text-gray-600">A piece cannot move because doing so would expose a more valuable piece behind it to capture.</p>
                </div>
                <div className="bg-gray-50 p-3 rounded-md">
                  <h3 className="font-medium">Skewer</h3>
                  <p className="text-sm text-gray-600">Similar to a pin, but the more valuable piece is in front, forcing it to move and allowing the capture of the piece behind.</p>
                </div>
                <div className="bg-gray-50 p-3 rounded-md">
                  <h3 className="font-medium">Discovered Attack</h3>
                  <p className="text-sm text-gray-600">Moving one piece reveals an attack from another piece behind it.</p>
                </div>
              </div>
            </div>
          </>
        );
      case 'endgame':
        return (
          <>
            <div className="w-full aspect-square mb-3 border border-gray-200 rounded-lg">
              <ChessBoard 
                fen={endGameChess.fen()} 
                possibleMoves={{}} 
                onSquareClick={() => {}}
              />
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-4 mb-6">
              <h2 className="font-heading font-semibold text-lg mb-3">Endgame Principles</h2>
              <div className="space-y-3">
                {endGamePrinciples.map(principle => (
                  <div key={principle.id} className="bg-gray-50 p-3 rounded-md">
                    <h3 className="font-medium">{principle.name}</h3>
                    <p className="text-sm text-gray-600 mt-1">{principle.description}</p>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-4 mb-6">
              <h2 className="font-heading font-semibold text-lg mb-3">Common Checkmate Patterns</h2>
              <div className="space-y-3">
                {checkmates.map(checkmate => (
                  <div key={checkmate.id} className="bg-gray-50 p-3 rounded-md">
                    <h3 className="font-medium">{checkmate.name}</h3>
                    <p className="text-sm text-gray-600 mt-1">{checkmate.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </>
        );
      default:
        return null;
    }
  };
  
  return (
    <div className="page pb-20">
      <header className="bg-primary px-5 py-6 shadow-md">
        <h1 className="text-white text-xl font-heading font-bold">Tutorial & Tips</h1>
      </header>

      <section className="px-5 py-6">
        <div className="flex mb-6 overflow-x-auto hide-scrollbar">
          {tabs.map(tab => (
            <button
              key={tab.id}
              className={`flex-shrink-0 py-2 px-4 rounded-md mr-2 text-sm font-medium ${
                activeTab === tab.id 
                  ? 'bg-accent text-white' 
                  : 'bg-gray-200 text-gray-700'
              }`}
              onClick={() => setActiveTab(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {renderTabContent()}

        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <h2 className="font-heading font-semibold text-lg mb-3">Interactive Lessons</h2>
          <div className="space-y-3">
            {lessons.map(lesson => (
              <div key={lesson.id} className="bg-gray-50 p-3 rounded-md">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">{lesson.title}</h3>
                    <p className="text-xs text-gray-500 mt-1">{lesson.description}</p>
                  </div>
                  <button 
                    className="bg-accent text-white py-1 px-3 rounded-md text-xs font-medium" 
                    onClick={() => handleStartLesson(lesson.title)}
                  >
                    Start
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-4">
          <h2 className="font-heading font-semibold text-lg mb-3">Daily Chess Puzzle</h2>
          <div className="border border-gray-200 rounded-lg p-3 mb-4">
            <div className="w-full aspect-square mb-3">
              <ChessBoard 
                fen={puzzleChess.fen()} 
                possibleMoves={{}} 
                onSquareClick={() => {}}
              />
            </div>
            <p className="text-sm mb-1 font-medium">{puzzles[0].task}</p>
            <p className="text-xs text-gray-600">Difficulty: {puzzles[0].difficulty}</p>
          </div>
          <div className="flex space-x-2">
            <button 
              className="flex-1 bg-accent hover:bg-accent-light text-white py-2 px-4 rounded-md text-sm font-medium transition-colors" 
              onClick={() => handleViewPuzzleSolution(puzzles[0].solution)}
            >
              View Solution
            </button>
            <button 
              className="flex-1 bg-secondary hover:bg-secondary-light text-white py-2 px-4 rounded-md text-sm font-medium transition-colors" 
              onClick={() => toast({
                title: "New Puzzle",
                description: "Loading a different puzzle..."
              })}
            >
              Next Puzzle
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Tutorial;
