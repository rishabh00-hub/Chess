import { useQuery } from '@tanstack/react-query';
import { useUser } from '@/context/UserContext';
import { useState } from 'react';

const Leaderboard = () => {
  const { user } = useUser();
  const [activeTab, setActiveTab] = useState('global');
  
  const { data: leaderboardData, isLoading } = useQuery({
    queryKey: ['/api/leaderboard'],
    retry: false,
  });
  
  const tabs = [
    { id: 'global', label: 'Global' },
    { id: 'friends', label: 'Friends' },
    { id: 'weekly', label: 'Weekly' }
  ];
  
  // Find user position in leaderboard
  const findUserPosition = () => {
    if (!user || !leaderboardData) return null;
    
    const index = leaderboardData.findIndex((player) => player.id === user.id);
    if (index === -1) return null;
    
    return {
      position: index + 1,
      ...leaderboardData[index]
    };
  };
  
  const userStats = findUserPosition();
  
  return (
    <div className="page pb-20">
      <header className="bg-primary px-5 py-6 shadow-md">
        <h1 className="text-white text-xl font-heading font-bold">Leaderboard</h1>
      </header>

      <section className="px-5 py-4">
        <div className="flex mb-4">
          {tabs.map(tab => (
            <button
              key={tab.id}
              className={`flex-1 py-2 border-b-2 font-medium ${
                activeTab === tab.id 
                  ? 'border-accent text-accent' 
                  : 'border-gray-200 text-gray-500'
              }`}
              onClick={() => setActiveTab(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="bg-white rounded-lg shadow overflow-hidden mb-4">
          <div className="bg-secondary text-white px-4 py-3 flex">
            <div className="w-10 text-center">#</div>
            <div className="flex-1">Player</div>
            <div className="w-16 text-center">Rating</div>
            <div className="w-16 text-center">W/L</div>
          </div>
          
          <div className="max-h-96 overflow-y-auto">
            {isLoading ? (
              <div className="p-4 text-center">Loading leaderboard...</div>
            ) : leaderboardData && leaderboardData.length > 0 ? (
              leaderboardData.map((player, index) => (
                <div 
                  key={player.id}
                  className={`px-4 py-3 flex items-center border-b border-gray-100 hover:bg-gray-50 ${
                    user && player.id === user.id ? 'bg-yellow-50' : ''
                  }`}
                >
                  <div className="w-10 text-center font-mono font-medium">{index + 1}</div>
                  <div className="flex-1 flex items-center">
                    <div className="w-8 h-8 rounded-full bg-gray-200 overflow-hidden mr-2">
                      <div className="w-full h-full flex items-center justify-center">
                        {player.username.charAt(0).toUpperCase()}
                      </div>
                    </div>
                    <span className="font-medium">{player.username}</span>
                  </div>
                  <div className="w-16 text-center font-mono">{player.rating}</div>
                  <div className="w-16 text-center text-sm">
                    <span className="text-green-600">--</span>/<span className="text-red-600">--</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-4 text-center">No leaderboard data available</div>
            )}
          </div>
          
          <div className="bg-gray-100 px-4 py-3 flex items-center">
            <div className="w-10 text-center font-mono font-medium">
              {userStats ? userStats.position : '--'}
            </div>
            <div className="flex-1 flex items-center">
              <div className="w-8 h-8 rounded-full bg-accent overflow-hidden mr-2">
                <div className="w-full h-full flex items-center justify-center text-white">
                  {user ? user.username.charAt(0).toUpperCase() : '?'}
                </div>
              </div>
              <span className="font-medium">You</span>
            </div>
            <div className="w-16 text-center font-mono">{user?.rating || '--'}</div>
            <div className="w-16 text-center text-sm">
              <span className="text-green-600">--</span>/<span className="text-red-600">--</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Leaderboard;
