import { useState, useEffect, useCallback } from 'react';
import { useWebSocket } from './useWebSocket';
import { 
  Chess, 
  ChessMove, 
  getInitialGameState, 
  calculateAllPossibleMoves,
  getUpdatedGameState 
} from '@/lib/chess';

export interface GameState {
  fen: string;
  turn: 'w' | 'b';
  inCheck: boolean;
  isCheckmate: boolean;
  isDraw: boolean;
  isGameOver: boolean;
  possibleMoves: Record<string, string[]>;
  selectedSquare: string | null;
  result: string | null;
}

export function useChessGame(gameId: number) {
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [lastMove, setLastMove] = useState<ChessMove | null>(null);
  const [isPendingMove, setIsPendingMove] = useState(false);
  
  // Connect to WebSocket
  const { 
    connected,
    sendMessage,
    lastMessage
  } = useWebSocket();
  
  // Initialize game state
  useEffect(() => {
    if (!gameId) return;
    
    console.log("Initializing game with ID:", gameId);
    
    // Initialize with a local game state for development
    const initialChess = new Chess();
    setGameState({
      fen: initialChess.fen(),
      turn: initialChess.turn() as 'w' | 'b',
      inCheck: initialChess.inCheck(),
      isCheckmate: initialChess.isCheckmate(),
      isDraw: initialChess.isDraw(),
      isGameOver: initialChess.isGameOver(),
      possibleMoves: calculateAllPossibleMoves(initialChess),
      selectedSquare: null,
      result: null
    });
    
    // When connected, authenticate and join the game
    if (connected) {
      console.log("WebSocket connected, joining game...");
      // Add a slight delay before connecting
      setTimeout(() => {
        // First authenticate
        sendMessage({
          type: 'auth'
        });
        
        // Then join the game
        sendMessage({
          type: 'join_game',
          gameId
        });
      }, 500);
    } else {
      console.log("Running in offline mode - local chess game only");
      // Force update after a short delay to ensure UI shows the board
      setTimeout(() => {
        setGameState(prevState => {
          if (!prevState) return null;
          return { ...prevState };
        });
      }, 1000);
    }
  }, [gameId, connected, sendMessage]);
  
  // Handle incoming WebSocket messages
  useEffect(() => {
    if (!lastMessage) return;
    
    try {
      const data = JSON.parse(lastMessage);
      
      switch (data.type) {
        case 'game_state':
          // Initialize the chess instance with the received FEN
          const chess = new Chess(data.fen);
          
          setGameState({
            fen: data.fen,
            turn: data.turn,
            inCheck: data.inCheck,
            isCheckmate: chess.isCheckmate(),
            isDraw: chess.isDraw(),
            isGameOver: data.isGameOver,
            possibleMoves: calculateAllPossibleMoves(chess),
            selectedSquare: null,
            result: data.result
          });
          break;
          
        case 'move_made':
          // Update the game state with the new move
          const chessAfterMove = new Chess(data.fen);
          
          setGameState({
            fen: data.fen,
            turn: data.turn,
            inCheck: data.inCheck,
            isCheckmate: chessAfterMove.isCheckmate(),
            isDraw: chessAfterMove.isDraw(),
            isGameOver: data.isGameOver,
            possibleMoves: calculateAllPossibleMoves(chessAfterMove),
            selectedSquare: null,
            result: data.result
          });
          
          // Extract the last move from the history
          const history = chessAfterMove.history({ verbose: true });
          if (history.length > 0) {
            const move = history[history.length - 1];
            setLastMove({
              from: move.from,
              to: move.to,
              promotion: move.promotion
            });
          }
          
          setIsPendingMove(false);
          break;
          
        case 'game_over':
          setGameState(prev => {
            if (!prev) return null;
            return {
              ...prev,
              isGameOver: true,
              result: data.result
            };
          });
          break;
          
        case 'draw_offer':
          // Handle draw offer (would show a dialog in a real app)
          console.log("Draw offered by", data.from);
          break;
          
        case 'error':
          console.error("Game error:", data.message);
          setIsPendingMove(false);
          break;
      }
    } catch (error) {
      console.error("Error processing WebSocket message:", error);
    }
  }, [lastMessage]);
  
  // Make a move
  const makeMove = useCallback((move: ChessMove) => {
    if (!gameState || gameState.isGameOver || isPendingMove) return;
    
    setIsPendingMove(true);
    
    // Send the move to the server if websocket is connected
    if (connected) {
      sendMessage({
        type: 'make_move',
        gameId,
        move: move
      });
    } else {
      // For local development, process the move locally
      try {
        const chess = new Chess(gameState.fen);
        const result = chess.move(move);
        if (result) {
          const newGameState = {
            fen: chess.fen(),
            turn: chess.turn() as 'w' | 'b',
            inCheck: chess.inCheck(),
            isCheckmate: chess.isCheckmate(),
            isDraw: chess.isDraw(),
            isGameOver: chess.isGameOver(),
            possibleMoves: calculateAllPossibleMoves(chess),
            selectedSquare: null,
            result: chess.isCheckmate() ? (chess.turn() === 'w' ? 'black' : 'white') : 
                   chess.isDraw() ? 'draw' : null
          };
          
          setGameState(newGameState);
          
          // Extract the last move from the history
          const history = chess.history({ verbose: true });
          if (history.length > 0) {
            const lastMove = history[history.length - 1];
            setLastMove({
              from: lastMove.from,
              to: lastMove.to,
              promotion: lastMove.promotion
            });
          }
        }
        setIsPendingMove(false);
      } catch (error) {
        console.error('Invalid move:', error);
        setIsPendingMove(false);
      }
    }
    
    // Update selected square
    setGameState(prev => {
      if (!prev) return null;
      return {
        ...prev,
        selectedSquare: null
      };
    });
  }, [gameState, gameId, isPendingMove, sendMessage, connected]);
  
  // Offer a draw
  const offerDraw = useCallback(() => {
    if (!gameState || gameState.isGameOver) return;
    
    sendMessage({
      type: 'offer_draw',
      gameId
    });
  }, [gameState, gameId, sendMessage]);
  
  // Accept a draw
  const acceptDraw = useCallback(() => {
    if (!gameState || gameState.isGameOver) return;
    
    sendMessage({
      type: 'accept_draw',
      gameId
    });
  }, [gameState, gameId, sendMessage]);
  
  // Resign game
  const resignGame = useCallback(() => {
    if (!gameState || gameState.isGameOver) return;
    
    sendMessage({
      type: 'resign',
      gameId
    });
  }, [gameState, gameId, sendMessage]);
  
  // Select a square
  const selectSquare = useCallback((square: string | null) => {
    setGameState(prev => {
      if (!prev) return null;
      
      return {
        ...prev,
        selectedSquare: square
      };
    });
  }, []);
  
  return {
    gameState,
    lastMove,
    isPendingMove,
    makeMove,
    offerDraw,
    acceptDraw,
    resignGame,
    selectSquare
  };
}
