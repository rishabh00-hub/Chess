declare global {
  interface Window {
    Telegram: {
      WebApp: {
        ready: () => void;
        expand: () => void;
        close: () => void;
        MainButton: {
          text: string;
          color: string;
          textColor: string;
          isVisible: boolean;
          isActive: boolean;
          isProgressVisible: boolean;
          onClick: (callback: () => void) => void;
          offClick: (callback: () => void) => void;
          show: () => void;
          hide: () => void;
          enable: () => void;
          disable: () => void;
          showProgress: (leaveActive: boolean) => void;
          hideProgress: () => void;
          setText: (text: string) => void;
          setParams: (params: {
            text?: string;
            color?: string;
            text_color?: string;
            is_active?: boolean;
            is_visible?: boolean;
          }) => void;
        };
        BackButton: {
          isVisible: boolean;
          onClick: (callback: () => void) => void;
          offClick: (callback: () => void) => void;
          show: () => void;
          hide: () => void;
        };
        initData: string;
        initDataUnsafe: {
          query_id?: string;
          user?: {
            id: number;
            first_name: string;
            last_name?: string;
            username?: string;
            language_code?: string;
            photo_url?: string;
          };
          auth_date?: number;
          hash?: string;
        };
      };
    };
  }
}

export function initializeTelegramWebApp() {
  if (window.Telegram?.WebApp) {
    // Tell Telegram WebApp that the page is ready
    window.Telegram.WebApp.ready();
    
    // Expand the WebApp to take up the full screen
    window.Telegram.WebApp.expand();
  } else {
    console.log('Telegram WebApp not available - running in standalone mode');
  }
}

export function getTelegramUser() {
  if (window.Telegram?.WebApp?.initDataUnsafe?.user) {
    return window.Telegram.WebApp.initDataUnsafe.user;
  }
  return null;
}

export function showTelegramMainButton(text: string, onClick: () => void) {
  if (window.Telegram?.WebApp?.MainButton) {
    const { MainButton } = window.Telegram.WebApp;
    
    MainButton.setText(text);
    MainButton.onClick(onClick);
    MainButton.show();
  }
}

export function hideTelegramMainButton() {
  if (window.Telegram?.WebApp?.MainButton) {
    const { MainButton } = window.Telegram.WebApp;
    
    MainButton.hide();
    MainButton.offClick(() => {});
  }
}

export function showTelegramBackButton(onClick: () => void) {
  if (window.Telegram?.WebApp?.BackButton) {
    const { BackButton } = window.Telegram.WebApp;
    
    BackButton.onClick(onClick);
    BackButton.show();
  }
}

export function hideTelegramBackButton() {
  if (window.Telegram?.WebApp?.BackButton) {
    const { BackButton } = window.Telegram.WebApp;
    
    BackButton.hide();
    BackButton.offClick(() => {});
  }
}

export function closeTelegramWebApp() {
  if (window.Telegram?.WebApp) {
    window.Telegram.WebApp.close();
  }
}
