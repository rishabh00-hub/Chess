// Re-export from chess.js to use throughout the application
import { Chess } from 'chess.js';
export { Chess };

export interface ChessMove {
  from: string;
  to: string;
  promotion?: string;
}

export interface GameState {
  fen: string;
  turn: 'w' | 'b';
  inCheck: boolean;
  isCheckmate: boolean;
  isDraw: boolean;
  isGameOver: boolean;
  possibleMoves: Record<string, string[]>;
  history: ChessMove[];
}

export function getInitialGameState(): GameState {
  const chess = new Chess();
  
  return {
    fen: chess.fen(),
    turn: chess.turn() as 'w' | 'b',
    inCheck: chess.inCheck(),
    isCheckmate: chess.isCheckmate(),
    isDraw: chess.isDraw(),
    isGameOver: chess.isGameOver(),
    possibleMoves: calculateAllPossibleMoves(chess),
    history: []
  };
}

// Calculate all possible moves for the current position
export function calculateAllPossibleMoves(chess: Chess): Record<string, string[]> {
  const possibleMoves: Record<string, string[]> = {};
  
  // Get all pieces of the current player's color
  const squares = chess.board();
  
  for (let i = 0; i < 8; i++) {
    for (let j = 0; j < 8; j++) {
      const piece = squares[i][j];
      if (piece && piece.color === chess.turn()) {
        const square = String.fromCharCode(97 + j) + (8 - i);
        const moves = chess.moves({ square, verbose: true });
        possibleMoves[square] = moves.map(move => move.to);
      }
    }
  }
  
  return possibleMoves;
}

// Get the updated game state after a move
export function getUpdatedGameState(chess: Chess, move: string | ChessMove): GameState | null {
  try {
    chess.move(move);
    
    return {
      fen: chess.fen(),
      turn: chess.turn() as 'w' | 'b',
      inCheck: chess.inCheck(),
      isCheckmate: chess.isCheckmate(),
      isDraw: chess.isDraw(),
      isGameOver: chess.isGameOver(),
      possibleMoves: calculateAllPossibleMoves(chess),
      history: chess.history({ verbose: true }) as ChessMove[]
    };
  } catch (error) {
    console.error('Invalid move:', error);
    return null;
  }
}

// Utility to get piece type and color from FEN position and square
export function getPieceAtSquare(fen: string, square: string): { type: string; color: 'w' | 'b' } | null {
  const chess = new Chess(fen);
  const file = square.charCodeAt(0) - 97; // 'a' -> 0, 'b' -> 1, etc.
  const rank = 8 - parseInt(square[1], 10); // '1' -> 7, '2' -> 6, etc.
  
  const piece = chess.board()[rank][file];
  return piece;
}

// Convert square notation (e.g., "e4") to board coordinates
export function squareToCoords(square: string): { row: number; col: number } {
  const file = square.charCodeAt(0) - 97; // 'a' -> 0, 'b' -> 1, etc.
  const rank = 8 - parseInt(square[1], 10); // '1' -> 7, '2' -> 6, etc.
  return { row: rank, col: file };
}

// Convert board coordinates to square notation
export function coordsToSquare(row: number, col: number): string {
  const file = String.fromCharCode(97 + col); // 0 -> 'a', 1 -> 'b', etc.
  const rank = 8 - row; // 7 -> '1', 6 -> '2', etc.
  return `${file}${rank}`;
}
