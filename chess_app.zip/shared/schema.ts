import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  telegramId: text("telegram_id").unique(),
  rating: integer("rating").notNull().default(0),
  level: integer("level").notNull().default(1),
  experience: integer("experience").notNull().default(0),
  points: integer("points").notNull().default(0),
  coins: integer("coins").notNull().default(0),
  playingStyle: jsonb("playing_style").$type<PlayingStyle>(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  whiteId: integer("white_id").notNull().references(() => users.id),
  blackId: integer("black_id").notNull().references(() => users.id),
  result: text("result"), // "white", "black", "draw", null if ongoing
  pgn: text("pgn"), // Portable Game Notation for the chess game
  timeControl: text("time_control").notNull(),
  isRated: boolean("is_rated").notNull().default(true),
  mode: text("mode").notNull(), // "ai", "friend", "quick", "betting"
  bettingAmount: integer("betting_amount"),
  startTime: timestamp("start_time").defaultNow(),
  endTime: timestamp("end_time"),
});

export const dailyTasks = pgTable("daily_tasks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  task: text("task").notNull(),
  description: text("description").notNull(),
  reward: integer("reward").notNull(),
  rewardType: text("reward_type").notNull(), // "xp", "coins"
  progress: integer("progress").notNull().default(0),
  target: integer("target").notNull(),
  completed: boolean("completed").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const moves = pgTable("moves", {
  id: serial("id").primaryKey(),
  gameId: integer("game_id").notNull().references(() => games.id),
  move: text("move").notNull(),
  fen: text("fen").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export type PlayingStyle = {
  aggressive: number;
  openingKnowledge: number;
  endgameSkills: number;
  tacticalVision: number;
};

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  telegramId: true,
});

export const insertGameSchema = createInsertSchema(games).pick({
  whiteId: true,
  blackId: true,
  timeControl: true,
  isRated: true,
  mode: true,
  bettingAmount: true,
});

export const insertMoveSchema = createInsertSchema(moves).pick({
  gameId: true,
  move: true,
  fen: true,
});

export const insertDailyTaskSchema = createInsertSchema(dailyTasks).pick({
  userId: true,
  task: true,
  description: true,
  reward: true,
  rewardType: true,
  target: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertGame = z.infer<typeof insertGameSchema>;
export type Game = typeof games.$inferSelect;

export type InsertMove = z.infer<typeof insertMoveSchema>;
export type Move = typeof moves.$inferSelect;

export type InsertDailyTask = z.infer<typeof insertDailyTaskSchema>;
export type DailyTask = typeof dailyTasks.$inferSelect;
